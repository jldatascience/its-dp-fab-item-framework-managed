"""Rejections — Gestion des rejets."""
