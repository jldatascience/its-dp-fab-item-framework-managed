"""RejectionHandler — Écriture des lignes rejetées dans le schéma ``rejects``.

Rôle dans le pipeline
---------------------
Après les contrôles DQ (``QualityChecker.check``), on obtient deux
DataFrames : ``valid`` (poursuit le traitement) et ``rejected`` (à isoler).
Le ``RejectionHandler`` est responsable de **persister** les lignes rejetées
dans une table Delta dédiée pour permettre :

- L'**audit métier** : pourquoi telle ligne a-t-elle été rejetée ?
- La **reprise** : le business peut corriger la source et rejouer.
- Le **suivi qualité** : dashboard des taux de rejet par table.

Conventions
-----------
- Table cible : ``<lakehouse>.rejects.rej_<table_name>``
- Mode : **append** (historique conservé, pas d'écrasement).
- ``mergeSchema=true`` : autorise l'évolution du schéma source dans le temps
  (nouvelles colonnes ajoutées, on ne bloque pas le pipeline).

Métadonnées ajoutées à chaque rejet
-----------------------------------
- ``_rejection_reason`` : raisons du rejet (concaténées avec ``|``), déjà
  posée par ``QualityChecker``.
- ``_rejected_at``      : timestamp du rejet (moment de l'écriture).
- ``_processing_id``    : identifiant du traitement (traçabilité vers les logs).
- ``_source_table``     : nom de la table source (utile si plusieurs sources
  écrivent dans la même table de rejets).
"""

from __future__ import annotations

import logging

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from dp_framework.config.models import TableMapping

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


class RejectionHandler:
    """Écrit les lignes rejetées dans le schéma ``rejects`` du lakehouse.

    Table cible : ``<lakehouse>.rejects.rej_<table_name>``.
    Mode : append (historique des rejets conservé).

    Métadonnées ajoutées automatiquement :

    - ``_rejection_reason`` : raison(s) du rejet (posée par ``QualityChecker``).
    - ``_rejected_at``      : timestamp du rejet.
    - ``_processing_id``    : identifiant du traitement.
    - ``_source_table``     : nom de la table source.

    Exemple:
        >>> handler = RejectionHandler(spark, "lh_storage")
        >>> n = handler.write(df_rejected, mapping, processing_id="proc-abc123")
        >>> # → écrit N lignes dans "lh_storage.rejects.rej_employee"
    """

    def __init__(self, spark: SparkSession, lakehouse: str) -> None:
        """Instancie le handler avec sa SparkSession et le lakehouse cible.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse contenant le schéma ``rejects``
                (ex : ``"lh_storage"``).

        """
        self._spark = spark
        self._lakehouse = lakehouse

    def write(self, df_rejected: DataFrame, mapping: TableMapping, processing_id: str) -> int:
        """Écrit les rejets dans la table dédiée et renvoie le nombre de lignes écrites.

        Séquence :

        1. Court-circuit si aucun rejet (économie d'un job Spark).
        2. Enrichissement du DataFrame avec les métadonnées du rejet.
        3. Écriture Delta en mode ``append`` avec ``mergeSchema=true``
           (tolère l'évolution du schéma source dans le temps).
        4. Récupération du nombre de lignes écrites via
           ``DESCRIBE HISTORY`` ⇒ Delta operationMetrics — évite un
           ``df.count()`` post-write qui déclencherait un second scan complet.

        Args:
            df_rejected: DataFrame contenant les lignes rejetées (avec la
                colonne ``_rejection_reason`` déjà posée par ``QualityChecker``).
            mapping: Configuration de la table (détermine le nom cible).
            processing_id: Identifiant du traitement courant (traçabilité).

        Returns:
            Nombre de lignes rejetées effectivement écrites (0 si aucun rejet).

        Exemple:
            Table source ``employee`` avec 2 lignes rejetées
            → écriture dans ``lh_storage.rejects.rej_employee``
            → chaque ligne a ``_rejected_at``, ``_processing_id``, ``_source_table``
              en plus des colonnes originales et de ``_rejection_reason``.

        """
        # Court-circuit : ne pas déclencher un job Spark pour 0 ligne.
        if df_rejected.isEmpty():
            _log.debug("[RejectionHandler][%s] Aucun rejet à écrire", mapping.name)
            return 0

        # Nom conventionnel de la table de rejets : préfixe ``rej_``.
        target_table = f"{self._lakehouse}.rejects.rej_{mapping.name}"
        _log.info(
            "[RejectionHandler][%s] Écriture des rejets dans '%s'",
            mapping.name,
            target_table,
        )

        # Enrichissement avec les métadonnées du rejet.
        # ``_rejection_reason`` est déjà présente (posée par QualityChecker).
        df_out = (
            df_rejected.withColumn("_rejected_at", F.current_timestamp())
            .withColumn("_processing_id", F.lit(processing_id))
            .withColumn("_source_table", F.lit(mapping.source_table))
        )

        # ``mergeSchema=true`` : si la source évolue (nouvelle colonne), Delta
        # ajoute la colonne à la table de rejets au lieu d'échouer. C'est
        # acceptable ici car la table de rejets n'est pas critique en
        # aval et son schéma peut grandir.
        df_out.write.format("delta").mode("append").option(
            "mergeSchema",
            "true",
        ).saveAsTable(target_table)

        # Récupération des métriques Delta via l'historique — évite un
        # ``df.count()`` post-write qui déclencherait un second scan complet.
        # ``numOutputRows`` est populé pour toutes les opérations d'écriture
        # (INSERT, MERGE, UPDATE) depuis Delta Lake 3.x.
        history = self._spark.sql(
            f"DESCRIBE HISTORY {target_table} LIMIT 1",
        ).first()
        metrics = history["operationMetrics"] if history else {}
        count = int(metrics.get("numOutputRows", 0))
        _log.info(
            "[RejectionHandler][%s] %d ligne(s) rejetée(s) écrite(s) dans '%s'",
            mapping.name,
            count,
            target_table,
        )
        return count
