"""Reader — Lecture des données source (staging pour ADP, DSO pour BDP).

Rôle dans le pipeline
---------------------
Point d'entrée unique pour lire les données source, en abstrayant deux modes
techniques distincts :

- **``lakehouse``** : lecture directe d'une table Delta d'un autre lakehouse
  Fabric via ``spark.table("{lh}.{schema}.{table}")``.
  → Utilisé principalement pour les ADP qui lisent depuis le lakehouse staging.

- **``synapsesql``** : lecture via le SQL Analytics Endpoint d'un lakehouse
  via ``spark.read.synapsesql("{lh}.{schema}.{table}")``, en s'appuyant sur
  l'identité MSI du notebook Fabric.
  → Utilisé principalement pour les BDP qui lisent depuis les vues DSO.

Le mode est déterminé par ``connection.type`` (résolu depuis
``connections/sources.yml``). L'appelant n'a pas à s'en soucier — il appelle
simplement ``reader.read(mapping)``.

Filtres appliqués systématiquement après la lecture :

- **Watermark** (mode incrémental) : ne conserve que les lignes plus
  récentes que la dernière valeur traitée.
- **Replay** (mode BDP) : filtre optionnel ``_valid_from >= replay_from_date``
  pour rejouer une plage temporelle.
"""

from __future__ import annotations

import logging

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from dp_framework.config.models import SourceConnection, TableMapping

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


class SourceReader:
    """Lit les données source selon le type de connexion défini dans ``sources.yml``.

    Deux modes de lecture sont supportés :

    - **``lakehouse``** : lit depuis un lakehouse Fabric via ``spark.table()``
      (format Delta Lake).
      Utilisé pour les ADP qui lisent depuis le Lakehouse Staging.

    - **``synapsesql``** : lit depuis le SQL Analytics Endpoint d'un lakehouse
      via ``spark.read.synapsesql()``. Utilisé pour les BDP qui lisent depuis
      le DSO.

    Le type de lecture est déterminé par ``connection.type``, résolu depuis
    les connexions chargées en amont (``connections/sources.yml``).

    Exemple d'usage:
        >>> reader = SourceReader(spark, "lh_storage", connections)
        >>> df = reader.read(mapping, last_watermark="2026-07-23")
    """

    def __init__(
        self,
        spark: SparkSession,
        lakehouse: str,
        connections: dict[str, SourceConnection],
    ) -> None:
        """Instancie un reader avec sa SparkSession et son dict de connexions.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse cible (ex : ``"lh_storage"``).
                Non utilisé directement par le reader mais gardé pour cohérence
                avec les autres composants (Logger, Writer, etc.).
            connections: Dictionnaire des connexions chargées depuis
                ``sources.yml`` (typiquement construit par
                ``YamlReader.read_connections()``).

        """
        self._spark = spark
        self._lakehouse = lakehouse
        self._connections = connections

    def read(self, mapping: TableMapping, last_watermark: str | None = None) -> DataFrame:
        """Lit les données source avec filtres incrémental et replay optionnels.

        Séquence d'exécution :

        1. Résolution de la connexion depuis ``mapping.source_connection``
           dans le dict de connexions.
        2. Dispatch vers ``read_from_lakehouse()`` ou ``read_from_sql_endpoint()``
           selon ``connection.type``.
        3. Application du filtre watermark (si ``load_mode="incremental"``).
        4. Application du filtre replay (si ``mapping.replay_from_date`` défini).

        Args:
            mapping: Configuration de la table (source + comportement).
            last_watermark: Dernière valeur watermark traitée (issue de la
                dernière exécution réussie). ``None`` = premier chargement
                ou mode ``full``.

        Returns:
            DataFrame avec les données source filtrées.

        Raises:
            ValueError: Si ``source_connection`` est absent du mapping,
                introuvable dans le dict, ou de type non supporté.

        Exemple:
            >>> # Lecture incrémentale
            >>> df = reader.read(mapping, last_watermark="2026-07-23 12:00:00")
            >>> # → lit toutes les lignes avec date_insert > 2026-07-23 12:00:00

            >>> # Lecture full (BDP)
            >>> df = reader.read(mapping)

        """
        # Résolution de la connexion + dispatch vers le lecteur approprié.
        connection = self._get_connection(mapping)
        _log.info(
            "[SourceReader][%s] Lecture depuis la source — type=%s, artifact=%s",
            mapping.name,
            connection.type,
            connection.artifact,
        )

        if connection.type == "lakehouse":
            df = self.read_from_lakehouse(mapping, connection)
        elif connection.type == "synapsesql":
            df = self.read_from_sql_endpoint(mapping, connection)
        else:
            # Message d'erreur explicite pour aider au diagnostic — on liste
            # les types supportés pour éviter les allers-retours.
            raise ValueError(
                f"Table '{mapping.name}': type de source non supporté '{connection.type}'. "
                "Types supportés : 'lakehouse', 'synapsesql'.",
            )

        # ----- Filtre incrémental -----
        # Ne conserver que les lignes plus récentes que le dernier watermark.
        # Trois conditions doivent être réunies : mode incrémental, colonne
        # définie, et une valeur watermark connue (sinon = premier chargement).
        if mapping.load_mode == "incremental" and mapping.watermark_column and last_watermark:
            _log.info(
                "[SourceReader][%s] Filtre incrémental appliqué — colonne=%s, depuis=%s",
                mapping.name,
                mapping.watermark_column,
                last_watermark,
            )
            # ``F.lit`` transforme la string en littéral Spark : évite les
            # risques d'injection SQL (comparé à un f-string dans expr()).
            df = df.filter(F.col(mapping.watermark_column) > F.lit(last_watermark))

        # ----- Filtre replay (BDP) -----
        # Permet de rejouer une plage temporelle en filtrant sur la colonne
        # ``_valid_from`` déjà présente dans les vues DSO (SCD2 upstream).
        if mapping.replay_from_date:
            _log.info(
                "[SourceReader][%s] Filtre replay_from_date appliqué — depuis=%s",
                mapping.name,
                mapping.replay_from_date,
            )
            df = df.filter(F.col("_valid_from") >= F.lit(mapping.replay_from_date))

        return df

    def read_from_lakehouse(self, mapping: TableMapping, connection: SourceConnection) -> DataFrame:
        """Lit depuis un lakehouse Fabric via ``spark.table()`` (format Delta Lake).

        Utilisé pour les ADP qui lisent depuis le Lakehouse Staging.
        La référence complète est : ``{connection.artifact}.{schema}.{table}``.

        Le ``source_schema`` du mapping prime sur ``connection.default_schema`` :
        cela permet à une même connexion d'être réutilisée pour plusieurs
        tables réparties dans plusieurs schémas.

        Args:
            mapping: Configuration de la table.
            connection: Connexion lakehouse résolue depuis ``sources.yml``.

        Returns:
            DataFrame brut depuis le lakehouse (sans filtre appliqué).

        Exemple:
            connection.artifact = "lh_staging"
            mapping.source_schema = "staging"
            mapping.source_table = "Groupementgup"
            → lecture de "lh_staging.staging.Groupementgup"

        """
        # Résolution du schéma : celui du mapping prime, fallback sur le défaut
        # de la connexion (ex : "dbo").
        schema = mapping.source_schema or connection.default_schema
        # Construction de la référence complète {artifact}.{schema}.{table}
        full_table_name = f"{connection.artifact}.{schema}.{mapping.source_table}"
        _log.info(
            "[SourceReader][%s] Lecture Lakehouse — table=%s",
            mapping.name,
            full_table_name,
        )
        return self._spark.table(full_table_name)

    def read_from_sql_endpoint(
        self, mapping: TableMapping, connection: SourceConnection
    ) -> DataFrame:
        """Lit depuis le SQL Analytics Endpoint d'un lakehouse via synapsesql (BDP).

        Sur Fabric, ``spark.read.synapsesql()`` utilise le SQL Analytics
        Endpoint du lakehouse DSO avec l'identité MSI du notebook (pas de mot
        de passe à gérer).

        La référence complète est : ``{connection.artifact}.{schema}.{table}``.

        Args:
            mapping: Configuration de la table.
            connection: Connexion synapsesql résolue depuis ``sources.yml``.

        Returns:
            DataFrame brut depuis le SQL endpoint (sans filtre appliqué).

        Exemple:
            connection.artifact = "lh_dso"
            mapping.source_schema = "schema_rh"
            mapping.source_table = "vw_employee_courante"
            → lecture de "lh_dso.schema_rh.vw_employee_courante"

        """
        # Même logique de résolution de schéma que pour le mode lakehouse.
        schema = mapping.source_schema or connection.default_schema
        # Construction de la référence synapsesql {artifact}.{schema}.{table}
        synapsesql_ref = f"{connection.artifact}.{schema}.{mapping.source_table}"
        _log.info(
            "[SourceReader][%s] Lecture SQL Endpoint — référence=%s",
            mapping.name,
            synapsesql_ref,
        )
        # NOTE : ``spark.read.synapsesql`` est une méthode Fabric-spécifique
        # (n'existe pas hors Fabric). L'authentification passe par la MSI
        # du notebook — aucun secret n'est manipulé.
        return self._spark.read.synapsesql(synapsesql_ref)

    # ------------------------------------------------------------------
    # Méthodes privées
    # ------------------------------------------------------------------

    def _get_connection(self, mapping: TableMapping) -> SourceConnection:
        """Résout la connexion depuis le dictionnaire des connexions chargées.

        Args:
            mapping: Configuration de la table (doit avoir ``source_connection``
                défini, sinon on ne sait pas où lire).

        Returns:
            L'objet ``SourceConnection`` correspondant.

        Raises:
            ValueError: Si ``source_connection`` est absent du mapping ou
                introuvable dans le dict de connexions. Le message d'erreur
                liste les connexions disponibles pour aider au diagnostic.

        """
        # Récupération du nom de connexion déclaré dans le mapping.
        conn_name = mapping.source_connection
        if not conn_name:
            # Cas fréquent en début de projet : le mapping oublie de référencer
            # une connexion. On lève un message explicite.
            raise ValueError(
                f"Table '{mapping.name}': 'source_connection' non défini dans tables_mapping.yml. "
                "Chaque table doit référencer une entrée de connections/sources.yml.",
            )
        conn = self._connections.get(conn_name)
        if conn is None:
            # Log + exception : le log est utile en Fabric où les stacktraces
            # peuvent être tronquées dans la sortie de la cellule.
            _log.error(
                "[SourceReader][%s] Connexion '%s' introuvable. Disponibles : %s",
                mapping.name,
                conn_name,
                list(self._connections.keys()),
            )
            raise ValueError(
                f"Table '{mapping.name}': connexion '{conn_name}' introuvable. "
                f"Connexions disponibles : {list(self._connections.keys())}",
            )
        _log.debug(
            "[SourceReader][%s] Connexion '%s' résolue (type=%s)",
            mapping.name,
            conn_name,
            conn.type,
        )
        return conn
