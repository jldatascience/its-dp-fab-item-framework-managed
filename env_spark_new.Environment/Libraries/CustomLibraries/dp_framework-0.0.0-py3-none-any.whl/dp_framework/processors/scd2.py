"""SCD2 — Gestion Slowly Changing Dimensions Type 2 via Delta MERGE.

Rôle dans le pipeline
---------------------
Point d'écriture pour les tables **historisées** : on conserve toutes les
versions successives d'une même ligne (clé fonctionnelle) au lieu de les
écraser. Chaque version est délimitée par ``_valid_from`` / ``_valid_to`` +
un flag ``_is_current`` sur la version active.

Approche
--------
Détection de changement via **hash SHA-256** sur les colonnes métier :

- Même clé + même hash ⇒ ligne inchangée ⇒ aucune écriture (idempotent).
- Même clé + hash différent ⇒ fermeture de l'ancienne version
  (``_valid_to=now``, ``_is_current=false``) ET insertion de la nouvelle
  (``_valid_from=now``, ``_valid_to=9999-12-31``, ``_is_current=true``),
  réalisées dans un **unique MERGE Delta** (une seule transaction).
- Nouvelle clé ⇒ insertion directe comme version courante (même MERGE).

Plusieurs traitements peuvent cibler la même table simultanément : Delta
utilise un contrôle de concurrence optimiste et peut donc faire échouer le
MERGE (conflit de fichiers). Ce cas est géré par un **retry** qui recalcule
intégralement les changements depuis l'état courant de la cible.

Colonnes techniques SCD2
------------------------
- ``_scd_hash``    : SHA-256 des colonnes métier (calculé par ce processor).
- ``_valid_from``  : début de validité de cette version.
- ``_valid_to``    : fin de validité (``9999-12-31`` pour la version active).
- ``_is_current``  : True pour la version active (une seule par clé).

Points d'attention
------------------
- Le calcul du hash **exclut** toutes les colonnes techniques (voir
  ``_TECHNICAL_COLS``) pour éviter de créer une nouvelle version à chaque
  run alors que la donnée métier n'a pas changé.
- Les valeurs ``NULL`` sont normalisées en ``"__NULL__"`` avant hash pour
  garantir le déterminisme (``NULL != NULL`` en SQL).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from dp_framework.config.models import DataContract, TableMapping

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


# Nom de la colonne technique portant le hash de détection de changement.
_SCD_HASH_COL = "_scd_hash"

# Sentinelle "infini" utilisée pour ``_valid_to`` des versions actives.
# Choix d'une date fixe (vs NULL) pour simplifier les BETWEEN et JOIN
# temporels côté BI.
_HIGH_DATE = "9999-12-31 00:00:00"

# Colonnes techniques à EXCLURE du calcul de hash. Les inclure créerait
# artificiellement une nouvelle version à chaque run (car ``_sequence_id`` /
# ``_processing_id`` / timestamps changent à chaque exécution).
_TECHNICAL_COLS = {
    "_sequence_id",
    "_processing_id",
    "_created_at",
    "_updated_at",
    "_valid_from",
    "_valid_to",
    "_is_current",
    "_is_deleted",
    "_deleted_at",
    "_scd_hash",
    "_rejection_reason",
}

# Colonne technique du staging indiquant l'action MERGE à appliquer par ligne :
# "CLOSE" (fermer la version courante) ou "INSERT" (poser la nouvelle version).
_MERGE_ACTION_COL = "_merge_action"

# Nombre max de tentatives sur conflit de concurrence Delta (writers concurrents
# sur la même table). Chaque tentative recalcule le staging depuis l'état courant.
_MAX_MERGE_ATTEMPTS = 3


@dataclass
class SCD2Metrics:
    """Métriques retournées par l'écriture SCD2.

    Attributes:
        rows_inserted: Nouvelles versions insérées (clés nouvelles + changements).
        rows_updated:  Anciennes versions **fermées** par ce run
            (``_is_current`` passé de true à false).
    """

    rows_inserted: int = 0
    rows_updated: int = 0  # versions fermées


class SCD2Processor:
    """Gère l'historisation SCD Type 2 via Delta Lake MERGE.

    Logique en un seul MERGE atomique :

    - Le staging porte une colonne ``_merge_action`` ("CLOSE" ou "INSERT") par
      ligne. Les clés modifiées génèrent 2 lignes de staging (CLOSE + INSERT),
      les clés nouvelles génèrent seulement une ligne INSERT.
    - La clause ``ON`` du MERGE restreint le matching aux lignes CLOSE contre
      la version courante : fermeture (UPDATE) et insertion (NOT MATCHED)
      sont validées dans une **unique transaction Delta**.

    Si hash identique ⇒ aucune ligne de staging ⇒ aucune écriture (idempotent).
    Sur conflit de concurrence Delta, la tentative est rejouée (voir
    ``_MAX_MERGE_ATTEMPTS``) en recalculant le staging depuis l'état courant
    de la cible.

    Exemple:
        >>> processor = SCD2Processor(spark, "lh_storage")
        >>> metrics = processor.write(df, mapping, contract, sequence_id, processing_id)
        >>> metrics.rows_inserted, metrics.rows_updated
        (5, 3)   # 3 versions modifiées + 2 clés totalement nouvelles = 5 inserts
    """

    def __init__(self, spark: SparkSession, lakehouse: str) -> None:
        """Instancie le processor avec sa SparkSession et le lakehouse cible.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse contenant le schéma cible.
        """
        self._spark = spark
        self._lakehouse = lakehouse

    def write(
        self,
        df: DataFrame,
        mapping: TableMapping,
        contract: DataContract,
        sequence_id: str,
        processing_id: str,
    ) -> SCD2Metrics:
        """Écrit les données avec logique SCD2 (historisation).

        Séquence :

        1. Validation : présence de clés fonctionnelles (obligatoire pour SCD2).
        2. Calcul du hash SHA-256 sur les colonnes métier
           (voir ``_compute_hash``).
        3. Premier chargement (table absente) ⇒ ``_initial_load`` (overwrite
           avec colonnes SCD2 posées).
        4. Sinon ⇒ ``_merge_scd2`` (2 étapes : close + insert).

        Args:
            df: DataFrame avec colonnes techniques déjà ajoutées par
                ``add_technical_columns()``.
            mapping: Configuration de la table.
            contract: Data contract (fournit les ``functional_keys``).
            sequence_id: Identifiant de la séquence (traçabilité).
            processing_id: Identifiant du step de traitement (traçabilité).

        Returns:
            ``SCD2Metrics(rows_inserted, rows_updated)``.

        Raises:
            ValueError: Si le contract ne définit aucune clé fonctionnelle
                (SCD2 ne peut pas fonctionner sans identifiant stable).
        """
        # Garde-fou : le schéma cible (ex. "adp", "bdp") doit exister avant tout
        # saveAsTable/MERGE. Sur un lakehouse Fabric "schema-enabled", un schéma
        # absent provoque une AnalysisException SCHEMA_NOT_FOUND peu explicite.
        self._ensure_schema_exists(mapping.target_schema)

        # Construction du nom complet de la table cible.
        target_table = f"{self._lakehouse}.{mapping.target_schema}.{mapping.target_table}"
        keys = contract.functional_keys

        # SCD2 exige une clé fonctionnelle stable — sinon on ne peut pas
        # identifier les versions d'une même entité.
        if not keys:
            raise ValueError(f"Aucune clé fonctionnelle pour la table '{mapping.name}'")

        # Garde-fou : détecte un contract/mapping désynchronisé du schéma réel.
        df_columns_lower = {column.lower() for column in df.columns}
        missing_keys = [key for key in keys if key.lower() not in df_columns_lower]
        if missing_keys:
            raise ValueError(
                f"Clé(s) fonctionnelle(s) absente(s) pour '{mapping.name}' : {missing_keys}"
            )

        # Colonnes métier = toutes SAUF clés fonctionnelles ET colonnes techniques.
        # Tri alphabétique pour un hash déterministe indépendant de l'ordre
        # des colonnes dans le DataFrame source.
        business_cols = sorted(c for c in df.columns if c not in set(keys) | _TECHNICAL_COLS)
        _log.info(
            "[SCD2][%s] Colonnes métier pour le hash (%d) : %s",
            mapping.name,
            len(business_cols),
            business_cols,
        )

        # Ajout de la colonne ``_scd_hash`` au DataFrame source.
        df_source = self._compute_hash(df, business_cols)

        # Premier chargement : pas de MERGE possible (la table n'existe pas
        # encore, Delta ne peut pas construire le plan MERGE).
        if not self._table_exists(target_table):
            _log.info(
                "[SCD2][%s] Table '%s' absente — premier chargement", mapping.name, target_table
            )
            return self._initial_load(df_source, target_table, mapping)

        # Cas nominal : MERGE SCD2 en 2 étapes.
        _log.info("[SCD2][%s] Exécution du MERGE SCD2 sur '%s'", mapping.name, target_table)
        return self._merge_scd2(df_source, target_table, keys, mapping, sequence_id, processing_id)

    def _initial_load(self, df: DataFrame, target_table: str, mapping: TableMapping) -> SCD2Metrics:
        """Premier chargement : écriture directe avec colonnes SCD2 posées.

        Toutes les lignes reçoivent :

        - ``_valid_from = now()`` (début de validité = maintenant)
        - ``_valid_to = 9999-12-31`` (sentinelle "infini")
        - ``_is_current = True`` (versions actives)

        Si ``soft_delete=true`` ⇒ ajout des colonnes ``_is_deleted`` (false)
        et ``_deleted_at`` (null).

        Args:
            df: DataFrame source avec hash déjà calculé.
            target_table: Nom complet de la table cible.
            mapping: Configuration (utilisée pour ``soft_delete``).

        Returns:
            ``SCD2Metrics(rows_inserted=N, rows_updated=0)``.
        """
        _log.info("[SCD2] Premier chargement dans '%s' — ajout des colonnes SCD2", target_table)
        now = F.current_timestamp()
        high_date = F.lit(_HIGH_DATE).cast("timestamp")

        # Ajout des 3 colonnes SCD2 (valid_from/valid_to/is_current).
        df_init = (
            df.withColumn("_valid_from", now)
            .withColumn("_valid_to", high_date)
            .withColumn("_is_current", F.lit(True))
        )

        # Colonnes soft delete conditionnelles.
        if mapping.soft_delete:
            df_init = df_init.withColumn("_is_deleted", F.lit(False)).withColumn(
                "_deleted_at", F.lit(None).cast("timestamp")
            )

        # Cache pour éviter un double scan du plan source (write + count).
        df_init = df_init.cache()
        try:
            count = df_init.count()
            # Écriture directe en overwrite : c'est le premier chargement,
            # la table est créée à la volée.
            df_init.write.format("delta").mode("overwrite").saveAsTable(target_table)
        finally:
            df_init.unpersist()
        _log.info(
            "[SCD2] Premier chargement terminé — %d ligne(s) insérée(s) dans '%s'",
            count,
            target_table,
        )
        return SCD2Metrics(rows_inserted=count)

    def _merge_scd2(
        self,
        df_source: DataFrame,
        target_table: str,
        keys: list[str],
        mapping: TableMapping,
        sequence_id: str,
        processing_id: str,
    ) -> SCD2Metrics:
        """Exécute le MERGE SCD2 atomique (fermeture + insertion en une transaction).

        Le staging (voir ``_build_staging``) porte une colonne
        ``_merge_action`` par ligne :

        - ``CLOSE``  : ferme la version courante existante (WHEN MATCHED).
        - ``INSERT`` : pose la nouvelle version, qu'elle remplace une version
          fermée ou qu'elle corresponde à une clé totalement nouvelle
          (WHEN NOT MATCHED).

        La clause ``ON`` du MERGE (voir ``_execute_merge``) restreint le
        matching aux seules lignes ``CLOSE`` contre la version courante — les
        lignes ``INSERT`` ne matchent donc jamais et tombent systématiquement
        dans la branche NOT MATCHED. Fermeture et insertion sont ainsi
        validées dans une **unique transaction Delta** : impossible d'avoir
        une clé sans version courante entre les deux opérations.

        Sur conflit de concurrence Delta (deux traitements réécrivant les
        mêmes fichiers), la tentative est rejouée jusqu'à
        ``_MAX_MERGE_ATTEMPTS`` fois. Chaque tentative reconstruit
        intégralement le staging depuis l'état courant de la cible (aucune
        donnée n'est réutilisée entre tentatives) — un rejeu avec la même
        donnée source ne crée donc jamais de version supplémentaire.

        Args:
            df_source: DataFrame source avec ``_scd_hash`` déjà posé.
            target_table: Nom complet de la table cible.
            keys: Clés fonctionnelles (colonnes de jointure).
            mapping: Configuration (utilisée pour ``soft_delete``).
            sequence_id: Identifiant de la séquence.
            processing_id: Identifiant du step de traitement.

        Returns:
            ``SCD2Metrics(rows_inserted, rows_updated)`` lues depuis les
            métriques natives de l'opération MERGE (``DeltaTable.history``).

        Raises:
            DeltaConcurrentModificationException: Si le conflit persiste
                après ``_MAX_MERGE_ATTEMPTS`` tentatives.
        """
        # Imports différés — voir explication dans soft_delete.py.
        # Côté client py4j (Fabric/Databricks), ces classes n'héritent PAS de
        # DeltaConcurrentModificationException (contrairement à Scala) — il
        # faut donc toutes les lister explicitement pour le retry.
        from delta.exceptions import (
            ConcurrentAppendException,
            ConcurrentDeleteDeleteException,
            ConcurrentDeleteReadException,
            ConcurrentTransactionException,
            ConcurrentWriteException,
            DeltaConcurrentModificationException,
            MetadataChangedException,
            ProtocolChangedException,
        )
        from delta.tables import DeltaTable

        concurrency_exceptions = (
            ConcurrentAppendException,
            ConcurrentDeleteReadException,
            ConcurrentDeleteDeleteException,
            ConcurrentTransactionException,
            ConcurrentWriteException,
            MetadataChangedException,
            ProtocolChangedException,
            DeltaConcurrentModificationException,
        )

        dt = DeltaTable.forName(self._spark, target_table)

        for attempt in range(1, _MAX_MERGE_ATTEMPTS + 1):
            # Timestamp unique par tentative (et non current_timestamp() SQL) :
            # borne _valid_to (CLOSE) et _valid_from (INSERT) de cette version,
            # doivent être strictement identiques pour ne pas casser la frontière.
            effective_at = F.lit(datetime.now(UTC)).cast("timestamp")

            # Reconstruction complète depuis l'état courant de la cible —
            # nécessaire pour que chaque tentative reflète les MERGE concurrents
            # déjà validés entre-temps par d'autres traitements.
            staging = self._build_staging(df_source, target_table, keys, mapping, effective_at)
            staging = staging.cache()
            try:
                _log.info(
                    "[SCD2][%s] MERGE atomique — tentative %d/%d sur '%s'",
                    mapping.name,
                    attempt,
                    _MAX_MERGE_ATTEMPTS,
                    target_table,
                )
                self._execute_merge(dt, staging, keys, sequence_id, processing_id, effective_at)
            except concurrency_exceptions as exc:
                if attempt == _MAX_MERGE_ATTEMPTS:
                    _log.error(
                        "[SCD2][%s] Conflit de concurrence Delta persistant après %d tentative(s) — abandon",
                        mapping.name,
                        attempt,
                    )
                    raise
                _log.warning(
                    "[SCD2][%s] Conflit de concurrence Delta (tentative %d/%d) — nouvel essai : %s",
                    mapping.name,
                    attempt,
                    _MAX_MERGE_ATTEMPTS,
                    exc,
                )
                continue
            finally:
                staging.unpersist()

            metrics = self._read_merge_metrics(dt)
            _log.info(
                "[SCD2][%s] MERGE terminé — insérées=%d, versions fermées=%d",
                mapping.name,
                metrics.rows_inserted,
                metrics.rows_updated,
            )
            return metrics

        # Inatteignable : la boucle se termine toujours par un ``return`` ou un ``raise``.
        raise RuntimeError(
            f"MERGE SCD2 impossible pour '{mapping.name}' après {_MAX_MERGE_ATTEMPTS} tentative(s)"
        )

    def _build_staging(
        self,
        df_source: DataFrame,
        target_table: str,
        keys: list[str],
        mapping: TableMapping,
        effective_at,
    ) -> DataFrame:
        """Construit les actions CLOSE et INSERT du MERGE SCD2.

        Classification des lignes source :

        - NEW :
        la clé n'existe pas dans les versions courantes de la cible ;
        produit une action INSERT.

        - CHANGED :
        la clé existe dans la cible, mais le hash métier est différent ;
        produit une action CLOSE et une action INSERT.

        - UNCHANGED :
        la clé existe et le hash métier est identique ;
        ne produit aucune action.

        Args:
            df_source:
                DataFrame source avec la colonne ``_scd_hash`` déjà calculée.
            target_table:
                Nom complet de la table Delta cible.
            keys:
                Clés fonctionnelles utilisées pour comparer source et cible.
            mapping:
                Configuration de la table, notamment l'activation du soft delete.
            effective_at:
                Timestamp commun à la fermeture de l'ancienne version et à
                l'ouverture de la nouvelle version.

        Returns:
            DataFrame contenant une ligne ``INSERT`` pour chaque clé nouvelle ou
            modifiée, et une ligne ``CLOSE`` supplémentaire pour chaque clé
            modifiée.
        """
        # ------------------------------------------------------------------
        # 1. Lecture des versions courantes de la cible
        # ------------------------------------------------------------------

        current_target = (
            self._spark.table(target_table)
            .filter(F.col("_is_current") == F.lit(True))
            .select(*keys, _SCD_HASH_COL)
        )

        # ------------------------------------------------------------------
        # 2. Comparaison de la source avec la cible courante
        # ------------------------------------------------------------------

        source_alias = "src"
        current_alias = "cur"

        joined = df_source.alias(source_alias).join(
            current_target.alias(current_alias),
            keys,
            "left_outer",
        )

        # La première clé sert uniquement de témoin pour déterminer si la
        # jointure a trouvé une version courante en cible.
        target_match_key = F.col(f"{current_alias}.{keys[0]}")

        source_hash = F.col(f"{source_alias}.{_SCD_HASH_COL}")
        current_hash = F.col(f"{current_alias}.{_SCD_HASH_COL}")

        target_exists = target_match_key.isNotNull()

        is_new = ~target_exists
        is_changed = target_exists & (source_hash != current_hash)

        # ------------------------------------------------------------------
        # 3. Conservation des lignes NEW et CHANGED
        # ------------------------------------------------------------------

        source_columns = [
            F.col(f"{source_alias}.{column}")
            for column in df_source.columns
        ]

        changes = (
            joined
            .filter(is_new | is_changed)
            .select(
                *source_columns,
                is_changed.alias("_is_changed"),
            )
        )

        # Les lignes UNCHANGED sont absentes de `changes`.
        # Elles ne produiront donc aucune action dans le MERGE.

        # ------------------------------------------------------------------
        # 4. Préparation des nouvelles versions courantes
        # ------------------------------------------------------------------

        high_date = F.lit(_HIGH_DATE).cast("timestamp")

        staged_versions = (
            changes
            .withColumn("_valid_from", effective_at)
            .withColumn("_valid_to", high_date)
            .withColumn("_is_current", F.lit(True))
        )

        if mapping.soft_delete:
            staged_versions = (
                staged_versions
                .withColumn("_is_deleted", F.lit(False))
                .withColumn(
                    "_deleted_at",
                    F.lit(None).cast("timestamp"),
                )
            )

        # ------------------------------------------------------------------
        # 5. Création des actions INSERT
        # ------------------------------------------------------------------

        # Toutes les clés NEW et CHANGED produisent une nouvelle version.
        insert_actions = staged_versions.withColumn(
            _MERGE_ACTION_COL,
            F.lit("INSERT"),
        )

        # ------------------------------------------------------------------
        # 6. Création des actions CLOSE
        # ------------------------------------------------------------------

        # Seules les clés CHANGED possèdent une ancienne version à fermer.
        close_actions = (
            staged_versions
            .filter(F.col("_is_changed"))
            .withColumn(
                _MERGE_ACTION_COL,
                F.lit("CLOSE"),
            )
        )

        # ------------------------------------------------------------------
        # 7. Regroupement des actions du MERGE
        # ------------------------------------------------------------------

        return (
            insert_actions
            .drop("_is_changed")
            .unionByName(
                close_actions.drop("_is_changed"),
            )
        )

    def _execute_merge(
        self,
        dt,
        staging: DataFrame,
        keys: list[str],
        sequence_id: str,
        processing_id: str,
        effective_at,
    ) -> None:
        """Exécute atomiquement les actions CLOSE et INSERT du staging SCD2.

        Le staging contient deux types d'actions :

        - CLOSE :
        recherche la version courante de la clé en cible, puis la ferme ;

        - INSERT :
        ne correspond volontairement à aucune ligne cible et insère une
        nouvelle version courante.

        La fermeture et l'insertion sont exécutées dans un seul MERGE Delta,
        donc dans une seule transaction.

        Args:
            dt:
                DeltaTable représentant la table cible.
            staging:
                DataFrame produit par ``_build_staging``. Il contient les
                données source et la colonne technique ``_merge_action``.
            keys:
                Clés fonctionnelles utilisées pour identifier une entité.
            sequence_id:
                Identifiant de la séquence ayant fermé l'ancienne version.
            processing_id:
                Identifiant du traitement ayant fermé l'ancienne version.
            effective_at:
                Timestamp commun à la fermeture de l'ancienne version et à
                l'ouverture de la nouvelle version.
        """
        target_alias = "target"
        source_alias = "source"

        # ------------------------------------------------------------------
        # 1. Construire la condition de jointure sur les clés fonctionnelles
        # ------------------------------------------------------------------

        key_match_condition = " AND ".join(
            f"{target_alias}.{key} = {source_alias}.{key}"
            for key in keys
        )

        # ------------------------------------------------------------------
        # 2. Limiter le matching aux actions CLOSE et aux versions courantes
        # ------------------------------------------------------------------

        current_version_condition = (
            f"{target_alias}._is_current = true"
        )
        close_action_condition = (
            f"{source_alias}.{_MERGE_ACTION_COL} = 'CLOSE'"
        )
        insert_action_condition = (
            f"{source_alias}.{_MERGE_ACTION_COL} = 'INSERT'"
        )

        merge_condition = " AND ".join(
            [
                key_match_condition,
                current_version_condition,
                close_action_condition,
            ]
        )

        # Une ligne INSERT ne satisfait jamais `merge_condition`, car cette
        # condition exige explicitement `_merge_action = 'CLOSE'`.
        # Elle est donc dirigée vers la branche WHEN NOT MATCHED.

        # ------------------------------------------------------------------
        # 3. Définir les colonnes mises à jour pour une action CLOSE
        # ------------------------------------------------------------------

        close_values = {
            # Fermer l'ancienne version au même instant que l'ouverture
            # de la nouvelle version.
            "_valid_to": effective_at,

            # L'ancienne version n'est plus la version courante.
            "_is_current": F.lit(False),

            # Tracer le traitement responsable de la fermeture.
            "_updated_at": effective_at,
            "_sequence_id": F.lit(sequence_id),
            "_processing_id": F.lit(processing_id),
        }

        # ------------------------------------------------------------------
        # 4. Définir les colonnes insérées pour une action INSERT
        # ------------------------------------------------------------------

        # Toutes les colonnes du staging sont insérées, sauf la colonne
        # `_merge_action`, utilisée uniquement pour router les actions.
        insert_values = {
            column: f"{source_alias}.{column}"
            for column in staging.columns
            if column != _MERGE_ACTION_COL
        }

        # ------------------------------------------------------------------
        # 5. Exécuter le MERGE Delta atomique
        # ------------------------------------------------------------------

        merge_builder = (
            dt.alias(target_alias)
            .merge(
                staging.alias(source_alias),
                merge_condition,
            )
            .whenMatchedUpdate(
                condition=close_action_condition,
                set=close_values,
            )
            .whenNotMatchedInsert(
                condition=insert_action_condition,
                values=insert_values,
            )
        )

        merge_builder.execute()

    def _read_merge_metrics(self, dt) -> SCD2Metrics:
        """Lit les métriques de la dernière opération MERGE via l'historique Delta.

        Évite un scan supplémentaire de la table cible (vs. un ``count()``
        post-write) : Delta calcule déjà ces compteurs pendant l'exécution
        du MERGE et les expose dans ``operationMetrics``.
        """
        operation_metrics = dt.history(1).select("operationMetrics").collect()[0][0]
        rows_inserted = int(operation_metrics.get("numTargetRowsInserted", 0))
        rows_updated = int(operation_metrics.get("numTargetRowsUpdated", 0))
        return SCD2Metrics(rows_inserted=rows_inserted, rows_updated=rows_updated)

    def _compute_hash(self, df: DataFrame, columns: list[str]) -> DataFrame:
        """Calcule un hash SHA-256 déterministe sur les colonnes métier.

        Le hash sert de "empreinte" de la ligne : deux lignes avec les mêmes
        valeurs métier auront le même hash, indépendamment des colonnes
        techniques ou de l'ordre d'écriture.

        Détails techniques :

        - Cast en string de chaque colonne pour uniformiser les types
          (int, timestamp, decimal… → tous en string avant concat).
        - ``NULL`` remplacé par ``"__NULL__"`` : sinon
          ``concat_ws("a", null, "b") = "ab"`` (silent skip), or on veut
          distinguer ``"a" + null + "b"`` de ``"a" + "" + "b"``.
        - Séparateur ``"||"`` pour désambiguer (``"ab"+"c"`` vs ``"a"+"bc"``).

        Args:
            df: DataFrame à hasher.
            columns: Colonnes métier à inclure (déjà pré-filtrées).

        Returns:
            DataFrame avec la colonne ``_scd_hash`` ajoutée (SHA-256 hex).

        Exemple:
            colonnes = ["name", "salary"]
            row = (name="Alice", salary=50000)
            → concat = "Alice||50000"
            → sha256 = "3e7b..."

            row2 = (name="Alice", salary=NULL)
            → concat = "Alice||__NULL__"
            → sha256 = "9a1c..." (différent de tout salaire numérique)
        """
        if not columns:
            # Cas dégénéré : que des clés fonctionnelles + colonnes techniques.
            # On pose un hash constant pour rendre le MERGE idempotent
            # (aucune nouvelle version ne sera jamais créée).
            _log.debug("[SCD2] Aucune colonne métier — hash statique 'no_business_cols'")
            return df.withColumn(_SCD_HASH_COL, F.lit("no_business_cols"))

        _log.debug("[SCD2] Calcul du hash SHA-256 sur %d colonne(s) : %s", len(columns), columns)
        # Concaténation avec ``concat_ws`` (séparateur "||") + null-safety
        # via ``coalesce`` sur ``__NULL__``.
        concat_expr = F.concat_ws(
            "||", *[F.coalesce(F.col(c).cast("string"), F.lit("__NULL__")) for c in columns]
        )
        # SHA-256 → 64 caractères hex. Suffisant pour éviter les collisions
        # dans un contexte SCD2 (probabilité négligeable à l'échelle métier).
        return df.withColumn(_SCD_HASH_COL, F.sha2(concat_expr, 256))

    def _ensure_schema_exists(self, schema: str) -> None:
        """Vérifie l'existence du schéma cible et le crée si absent.

        Contexte
        --------
        Le framework historise ADP et BDP dans **deux schémas distincts**
        (``adp`` / ``bdp``) au sein du **même lakehouse** ``lh_storage``
        (voir ``CONTEXT.md``). Ces schémas ne sont pas créés à l'avance par
        Fabric — le premier run sur une table d'un nouveau schéma échouerait
        avec ``SCHEMA_NOT_FOUND`` sans ce garde-fou.

        Utilise ``spark.catalog.databaseExists()`` (nom à 2 niveaux
        ``lakehouse.schema``) plutôt qu'un ``SHOW SCHEMAS IN <lakehouse>`` —
        plus direct et sans dépendre du parsing du résultat.

        Args:
            schema: Nom du schéma cible (ex. ``mapping.target_schema``,
                typiquement ``"adp"`` ou ``"bdp"``).
        """
        full_schema = f"{self._lakehouse}.{schema}"
        if self._spark.catalog.databaseExists(full_schema):
            _log.debug("[SCD2] Schéma '%s' déjà existant", full_schema)
            return
        _log.info("[SCD2] Schéma '%s' absent — création", full_schema)
        self._spark.sql(f"CREATE SCHEMA IF NOT EXISTS {full_schema}")

    def _table_exists(self, table_name: str) -> bool:
        """Vérifie si une table Delta existe via le catalog Spark.

        Utilise ``spark.catalog.tableExists()`` (Spark 3.5+) plutôt qu'un
        ``try/except`` sur ``spark.table()`` :

        - **plus rapide** : pas d'exception à lever/capturer,
        - **sémantique explicite** : intention claire pour le lecteur,
        - **pas de chargement de métadonnées** inutile en cas d'absence.
        """
        exists = self._spark.catalog.tableExists(table_name)
        _log.debug(
            "[SCD2] Table '%s' %s",
            table_name,
            "trouvée" if exists else "absente (premier chargement)",
        )
        return exists
