"""Colonnes techniques — Ajout des champs de traçabilité.

Rôle dans le pipeline
---------------------
Après la validation contract + DQ, on injecte des colonnes techniques dans
le DataFrame **avant** l'écriture SCD1/SCD2. Ces colonnes servent à :

- **Traçabilité** : retrouver quelle exécution a créé/modifié une ligne
  (``_sequence_id``, ``_processing_id``).
- **Audit** : dates de création et de dernière modification
  (``_created_at``, ``_updated_at``).
- **Jointure avec les logs** : les colonnes ``_sequence_id`` et
  ``_processing_id`` sont clés étrangères vers les tables
  ``observability.log_sequence`` et ``observability.log_processing``.

Colonnes SCD2 (``_valid_from``, ``_valid_to``, ``_is_current``) et soft delete
(``_is_deleted``, ``_deleted_at``) sont ajoutées séparément par les
processeurs correspondants (``SCD2Processor`` / ``SoftDeleteProcessor``).
"""

from __future__ import annotations

import logging

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


def add_technical_columns(df: DataFrame, sequence_id: str, processing_id: str) -> DataFrame:
    """Ajoute les colonnes techniques de traçabilité à un DataFrame.

    Colonnes ajoutées (toujours, quelle que soit la table) :

    - ``_sequence_id``     : identifiant de la séquence (FK vers ``log_sequence``)
    - ``_processing_id``   : identifiant du traitement de la table (FK vers ``log_processing``)
    - ``_created_at``      : timestamp de création (**init du run courant**)
    - ``_updated_at``      : timestamp de dernière modification (**init du run courant**)

    Comportement lors de l'écriture :

    - **INSERT** : ``_created_at`` et ``_updated_at`` reçoivent tous deux
      ``current_timestamp()``.
    - **UPDATE (SCD1)** : ``_created_at`` est **préservé** (voir
      ``Writer._upsert()``), seul ``_updated_at`` est mis à jour.
    - **SCD2** : chaque nouvelle version a son propre ``_created_at``.

    Args:
        df: DataFrame après DQ (colonnes finales déjà nommées).
        sequence_id: Identifiant de la séquence (généré par
            ``nb_log_sequence_start``, propagé au pipeline).
        processing_id: Identifiant du traitement (généré par
            ``nb_log_processing_start`` au début de ``Pipeline.run``).

    Returns:
        Un nouveau DataFrame avec les 4 colonnes techniques ajoutées.
        L'ordre des colonnes existantes est préservé (les nouvelles sont
        ajoutées à la fin).

    Exemple:
        >>> df = spark.createDataFrame([(1, "Alice")], ["id", "name"])
        >>> df_tech = add_technical_columns(df, "sequence-2026-07-24", "proc-abc123")
        >>> df_tech.columns
        ['id', 'name', '_sequence_id', '_processing_id', '_created_at', '_updated_at']

    """
    _log.debug(
        "[TechnicalColumns] Ajout des colonnes de traçabilité (sequence_id=%s, processing_id=%s)",
        sequence_id,
        processing_id,
    )
    # ``current_timestamp()`` est évalué côté Spark ⇒ même valeur pour toutes
    # les lignes de ce batch, correspond à l'instant d'écriture (pas au moment
    # de cet appel Python).
    now = F.current_timestamp()
    return (
        df.withColumn("_sequence_id", F.lit(sequence_id))
        .withColumn("_processing_id", F.lit(processing_id))
        # ``_created_at`` = ``_updated_at`` à l'INSERT initial. Lors des UPDATE
        # (SCD1 upsert), le writer préserve ``_created_at`` et ne met à jour
        # que ``_updated_at``.
        .withColumn("_created_at", now)
        .withColumn("_updated_at", now)
    )
