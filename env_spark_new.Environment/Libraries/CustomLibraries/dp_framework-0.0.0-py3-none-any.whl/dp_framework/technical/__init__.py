"""Technical — Colonnes techniques et temporelles."""
