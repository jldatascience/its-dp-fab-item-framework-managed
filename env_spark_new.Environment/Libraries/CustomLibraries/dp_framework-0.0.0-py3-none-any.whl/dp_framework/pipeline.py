"""Pipeline — Orchestration unifiée ADP & BDP.

Rôle
----
Point d'entrée unique du framework. Une même classe ``Pipeline`` orchestre
les deux types de data product :

- **ADP** (Application Data Product) : staging → contract → DQ → storage.
- **BDP** (Business Data Product)    : DSO → transform → contract → DQ → storage.

Le paramètre ``dp_type`` détermine le comportement :

+----------+------------------+--------+----------+--------------+
| Étape    | Description      | ADP    | BDP      | Commentaire  |
+==========+==================+========+==========+==============+
| Read     | Source           | ✅     | ✅       |              |
+----------+------------------+--------+----------+--------------+
| Contract | Validation       | ✅     | ✅       |              |
+----------+------------------+--------+----------+--------------+
| Rename   | Map cols source  | ✅     | ✅       |              |
+----------+------------------+--------+----------+--------------+
| DQ       | Contrôles qualité| complet| ciblé    |              |
+----------+------------------+--------+----------+--------------+
| Reject   | Table de rejets  | ✅     | ✅       |              |
+----------+------------------+--------+----------+--------------+
| Transform| Hook métier      | ❌     | ✅       | BDP-only     |
+----------+------------------+--------+----------+--------------+
| Tech cols| Traçabilité      | ✅     | ✅       |              |
+----------+------------------+--------+----------+--------------+
| SoftDel  | Suppr. logiques  | opt.   | opt.     | mapping-driven|
+----------+------------------+--------+----------+--------------+
| Write    | SCD2 ou SCD1     | ✅     | ✅       |              |
+----------+------------------+--------+----------+--------------+
| Log      | Événement fin    | ✅     | ✅       | append-only  |
+----------+------------------+--------+----------+--------------+

Principes clés
--------------
- **Configuration externalisée** : le pipeline ne lit **jamais** de fichier
  YAML lui-même. C'est le notebook appelant qui construit ``TableMapping`` /
  ``DataContract`` via ``YamlReader`` et les passe à ``run()``.
- **Cache DataFrame source** : la source est cachée après la lecture pour
  éviter des re-scans coûteux (count, DQ, transform utilisent tous le même
  DataFrame). ``unpersist()`` garanti via ``try/finally``.
- **Logging complet** : l'événement STARTED de l'étape ``INGESTION`` est
  écrit par le notebook appelant (``nb_log_processing_start``) *avant*
  l'appel à ``run()`` — ``processing_id`` est donc fourni en entrée, jamais
  généré par le pipeline. ``run()`` écrit uniquement l'événement COMPLETED
  dans ``observability.log_processing``, avec toutes les métriques.
- **Gestion d'erreur exhaustive** : ``ContractViolationError`` et exceptions
  génériques sont capturées pour toujours enregistrer un événement de fin
  (statut ``failure`` + message d'erreur), garantissant la traçabilité.

Usage
-----
    from dp_framework import Pipeline
    from dp_framework.config.yaml_reader import YamlReader

    reader = YamlReader(spark, metadata_root)

    # sequence_id / load_id / processing_id sont fournis par les notebooks
    # nb_log_sequence_start / nb_log_load_start / nb_log_processing_start,
    # exécutés en amont par l'orchestration Fabric.

    # --- ADP ---
    mapping     = reader.read_mapping(TABLE_NAME)
    contract    = reader.read_contract(TABLE_NAME)
    connections = reader.read_connections()   # adp/connections/sources.yml
    pipeline    = Pipeline(spark, lakehouse="lh_storage", dp_type="ADP",
                           connections=connections)
    result      = pipeline.run(mapping, sequence_id="<sequence_id>",
                               load_id="<load_id>", processing_id="<processing_id>",
                               contract=contract)

    # --- BDP ---
    mapping     = reader.read_mapping(TABLE_NAME)
    connections = reader.read_connections()   # bdp/connections/sources.yml
    contract    = reader.read_contract(TABLE_NAME)
    pipeline    = Pipeline(spark, lakehouse="lh_storage", dp_type="BDP",
                           connections=connections)
    result      = pipeline.run(mapping, sequence_id="<sequence_id>",
                               load_id="<load_id>", processing_id="<processing_id>",
                               contract=contract)
"""

from __future__ import annotations

import logging

from pyspark.sql import DataFrame, SparkSession

from dp_framework.config.models import (
    DataContract,
    ProcessingResult,
    SourceConnection,
    TableMapping,
)
from dp_framework.contracts.validator import ContractValidator, ContractViolationError
from dp_framework.logging.logger import Logger
from dp_framework.processors.reader import SourceReader
from dp_framework.processors.scd2 import SCD2Processor
from dp_framework.processors.soft_delete import SoftDeleteProcessor
from dp_framework.processors.writer import Writer
from dp_framework.quality.checks import QualityChecker
from dp_framework.rejections.handler import RejectionHandler
from dp_framework.technical.columns import add_technical_columns

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


class Pipeline:
    """Pipeline unifié pour le traitement des tables ADP et BDP.

    La configuration (mapping + contract) est toujours fournie par le notebook
    appelant via ``YamlReader``. Le Pipeline ne lit jamais de fichier YAML
    lui-même — cela garde le pipeline **testable** et **découplé** du
    stockage des métadonnées.

    Deux flux :

        - **ADP** : staging → validate contract → DQ → colonnes techniques →
            SCD2 → log. Le hook ``transform()`` n'est jamais appelé.
        - **BDP** : DSO (synapsesql) → transform → validate contract → DQ ciblée →
            colonnes techniques → soft delete → SCD2 → log.

    Usage dans un notebook Fabric (voir docstring module pour l'exemple complet).
    """

    _ADP_DQ_CHECKS = frozenset({"completeness", "validity", "duplicate_row", "uniqueness"})
    _BDP_DQ_CHECKS = frozenset({"completeness", "duplicate_row", "uniqueness"})
    _SCD2_REQUIRED_COLUMNS = frozenset(
        {
            "_scd_hash",
            "_valid_from",
            "_valid_to",
            "_is_current",
            "_created_at",
            "_updated_at",
            "_sequence_id",
            "_processing_id",
        }
    )
    _SOFT_DELETE_REQUIRED_COLUMNS = frozenset(
        {
            "_is_current",
            "_is_deleted",
            "_deleted_at",
            "_updated_at",
            "_sequence_id",
            "_processing_id",
        }
    )

    def __init__(
        self,
        spark: SparkSession,
        lakehouse: str,
        dp_type: str = "ADP",
        connections: dict[str, SourceConnection] | None = None,
    ) -> None:
        """Instancie un pipeline et tous ses sous-composants.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse cible (ex : ``"lh_storage"``).
            dp_type: Type de data product — ``"ADP"`` ou ``"BDP"``.
                Contrôle le comportement du pipeline (validation contract,
                DQ, etc.).
            connections: Connexions chargées depuis ``connections/sources.yml``.
                Obligatoire pour ADP et BDP — chaque table doit référencer
                une entrée du dictionnaire via son champ ``source_connection``.

        Raises:
            ValueError: Si ``dp_type`` n'est ni ``"ADP"`` ni ``"BDP"``.

        """
        # Validation fail-fast : seuls ADP et BDP sont supportés.
        # Une typo silencieuse ici mènerait à un pipeline mal configuré
        # (validation contract manquante côté ADP par exemple).
        if dp_type not in ("ADP", "BDP"):
            raise ValueError(f"dp_type doit être 'ADP' ou 'BDP', reçu : '{dp_type}'")

        # Stockage des paramètres de base de l'instance.
        self._spark = spark
        self._lakehouse = lakehouse
        self._dp_type = dp_type

        _log.info("[Pipeline] Initialisation — type=%s, lakehouse=%s", dp_type, lakehouse)

        # Initialisation de tous les composants du pipeline.
        # ``connections or {}`` : tolère l'absence pour des cas de tests /
        # premier prototype où on n'a pas encore configuré de sources.
        self._connections = connections or {}
        self._reader = SourceReader(spark, lakehouse, self._connections)
        self._contract_validator = ContractValidator()
        self._quality_checker = QualityChecker()
        self._rejection_handler = RejectionHandler(spark, lakehouse)
        self._scd2 = SCD2Processor(spark, lakehouse)
        self._writer = Writer(spark, lakehouse)
        self._soft_deleter = SoftDeleteProcessor(spark, lakehouse)
        self._logger = Logger(spark, lakehouse)

        _log.info("[Pipeline] Tous les composants sont initialisés avec succès")

    def run(
        self,
        mapping: TableMapping,
        sequence_id: str,
        load_id: str,
        processing_id: str,
        contract: DataContract | None = None,
        last_watermark: str | None = None,
    ) -> ProcessingResult:
        """Point d'entrée unique — traite une table de bout en bout.

        Séquence complète (voir table ADP/BDP dans le docstring module) :

        1. Lecture source + cache (pour éviter les re-scans).
        2. ADP : validation contract → renommage → DQ complète.
        3. BDP : transformation → validation contract → renommage → DQ ciblée.
        4. Écriture des rejets pour les deux types.
        5. Ajout des colonnes techniques (``_sequence_id``, ``_processing_id``…).
        6. (Optionnel) Soft delete si ``mapping.soft_delete=true``.
        7. Écriture (SCD2 si ``scd_type=2``, sinon SCD1/full).
        8. Log ``COMPLETED`` (statut + métriques).

        L'événement ``STARTED`` de l'étape ``INGESTION`` est écrit **avant**
        cet appel par le notebook ``nb_log_processing_start`` — ``run()`` ne
        génère jamais son propre ``processing_id``, il utilise celui fourni
        en argument.

        En cas d'exception :

        - ``ContractViolationError`` ⇒ statut ``failure`` + message.
        - Toute autre exception ⇒ statut ``failure`` + type + message.
        - Le log ``COMPLETED`` est **toujours** écrit (bloc try/except/finally).
        - Le DataFrame source caché est toujours ``unpersist()`` via ``finally``.

        Args:
            mapping: TableMapping construit depuis le YAML par le notebook.
            sequence_id: Identifiant de la séquence parente (généré en amont
                par ``nb_log_sequence_start``). Obligatoire.
            load_id: Identifiant du chargement parent (généré en amont par
                ``nb_log_load_start``). Obligatoire.
            processing_id: Identifiant de l'étape ``INGESTION`` (généré en
                amont par ``nb_log_processing_start``, avec
                ``processing_name="INGESTION"``). Obligatoire.
            contract: DataContract construit depuis le YAML, obligatoire pour
                ADP et BDP.
            last_watermark: Dernière valeur watermark traitée
                (mode incrémental ADP). ``None`` = full ou 1er chargement.

        Returns:
            ``ProcessingResult(status, table_name, rows_read, ..., error_message)``.

        Raises:
            ValueError: Si la configuration du mapping, du contrat ou de la
                connexion est incompatible avec le pipeline.

        """
        # Garde-fous exécutés avant le STARTED : une erreur de configuration
        # ne doit pas créer un traitement qui resterait artificiellement "running".
        if mapping.dp_type != self._dp_type:
            raise ValueError(
                f"Table '{mapping.name}': dp_type du mapping '{mapping.dp_type}' "
                f"incompatible avec le pipeline '{self._dp_type}'."
            )

        # Le contrat pilote le schéma, la clé primaire, le renommage et la DQ
        # pour les deux types de Data Product.
        if contract is None:
            raise ValueError(
                f"Table '{mapping.name}': contract obligatoire pour un pipeline {self._dp_type}."
            )

        if contract.table_name != mapping.name:
            raise ValueError(
                f"Table '{mapping.name}': le contract cible '{contract.table_name}'."
            )

        # Une BDP est toujours alimentée depuis une vue DSO par le SQL Endpoint.
        # Cette contrainte évite qu'un mapping BDP contourne le DSO via spark.table().
        if self._dp_type == "BDP":
            connection_name = mapping.source_connection
            if not connection_name or connection_name not in self._connections:
                raise ValueError(
                    f"Table BDP '{mapping.name}': connexion source "
                    f"'{connection_name}' introuvable."
                )

            connection = self._connections[connection_name]
            if connection.type != "synapsesql":
                raise ValueError(
                    f"Table BDP '{mapping.name}': la source doit être un DSO via "
                    f"'synapsesql', reçu '{connection.type}'."
                )

        table_name = mapping.name
        _log.info(
            "[Pipeline] Démarrage — table=%s, sequence_id=%s, load_id=%s, "
            "processing_id=%s, dp_type=%s",
            table_name,
            sequence_id,
            load_id,
            processing_id,
            self._dp_type,
        )

        # ``processing_id`` est fourni par l'appelant (nb_log_processing_start
        # a déjà écrit l'événement STARTED avant cet appel) — le pipeline ne
        # génère jamais son propre identifiant, pour ne pas créer un
        # processing_id "fantôme" distinct de celui suivi par l'orchestration.

        # Référence vers le DataFrame source caché — permet de libérer la
        # mémoire dans le bloc ``finally``, même en cas d'exception.
        df_cached: DataFrame | None = None
        try:
            # ----------------------------------------------------------------
            # ÉTAPE 1 — Lecture de la source
            # ----------------------------------------------------------------
            _log.info(
                "[Pipeline][%s] Lecture de la source (watermark=%s)",
                table_name,
                last_watermark,
            )
            df = self._reader.read(mapping, last_watermark)
            # Cache Spark : le DataFrame source est utilisé par plusieurs
            # étapes aval (count, contract, DQ avec fenêtres multiples).
            # Sans cache, Spark ré-exécute tout le plan de lecture pour
            # chaque action ⇒ coût multiplié par le nombre d'actions.
            # On dépersiste à la fin (bloc ``finally``) quel que soit le statut.
            df = df.cache()
            df_cached = df
            # Premier ``count()`` : matérialise le cache (une seule fois).
            rows_read = df.count()
            _log.info(
                "[Pipeline][%s] Lecture terminée — %d ligne(s) lue(s)",
                table_name,
                rows_read,
            )

            # Arrêt anticipé si la source est vide : rien à traiter, pas
            # besoin d'exécuter DQ / SCD2 / etc. On loggue quand même un
            # ``success`` avec ``rows_read=0`` pour tracer que le run a bien
            # eu lieu (utile pour distinguer "pas de données" de "pas exécuté").
            if rows_read == 0:
                _log.info(
                    "[Pipeline][%s] Source vide — pipeline terminé sans traitement",
                    table_name,
                )
                result = ProcessingResult(table_name=table_name, status="success", rows_read=0)
                self._logger.log_processing_end(
                    sequence_id, load_id, processing_id, table_name, "INGESTION", result
                )
                return result

            # ----------------------------------------------------------------
            # ÉTAPE 2 — Préparation selon le type de Data Product
            # ----------------------------------------------------------------
            if self._dp_type == "ADP":
                # Fidélité source : aucun hook métier n'est autorisé sur un ADP.
                df_prepared = df
                enabled_checks = self._ADP_DQ_CHECKS
            else:
                # Le contrat BDP décrit la sortie métier : il est donc validé
                # après transform(), contrairement au contrat ADP validé sur la source.
                _log.info("[Pipeline][%s] Application des transformations métier", table_name)
                df_prepared = self.transform(df, mapping, contract)
                enabled_checks = self._BDP_DQ_CHECKS

            _log.info("[Pipeline][%s] Validation du contract en cours...", table_name)
            self._contract_validator.validate(df_prepared, contract)
            _log.info("[Pipeline][%s] Contract validé avec succès", table_name)

            _log.info("[Pipeline][%s] Application du mapping de colonnes", table_name)
            df_prepared = self._apply_column_mapping(df_prepared, contract)

            # ----------------------------------------------------------------
            # ÉTAPE 3 — Contrôles qualité et écriture des rejets
            # ----------------------------------------------------------------
            rows_rejected = 0
            _log.info("[Pipeline][%s] Exécution des contrôles qualité (DQ)", table_name)
            quality_result = self._quality_checker.check(
                df_prepared, contract, enabled_checks=enabled_checks
            )
            df_valid = quality_result.valid
            df_rejected = quality_result.rejected

            if not df_rejected.isEmpty():
                _log.warning(
                    "[Pipeline][%s] Des lignes ont été rejetées — écriture dans la table de rejets",
                    table_name,
                )
                rows_rejected = self._rejection_handler.write(
                    df_rejected, mapping, processing_id
                )

            rows_valid = df_valid.count()
            _log.info(
                "[Pipeline][%s] DQ terminé — %d valide(s), %d rejeté(s)",
                table_name,
                rows_valid,
                rows_rejected,
            )

            # ----------------------------------------------------------------
            # ÉTAPE 4 — Ajout des colonnes techniques
            # ----------------------------------------------------------------
            # ``_sequence_id``, ``_processing_id``, ``_created_at``
            # sont ajoutés après la préparation propre au type de Data Product.
            # Les ADP ne passent jamais par une transformation métier.
            _log.info("[Pipeline][%s] Ajout des colonnes techniques", table_name)
            df_valid = add_technical_columns(df_valid, sequence_id, processing_id)

            # ----------------------------------------------------------------
            # ÉTAPE 5 — Soft delete (si activé sur le mapping)
            # ----------------------------------------------------------------
            rows_deleted = 0
            if mapping.soft_delete:
                _log.info(
                    "[Pipeline][%s] Soft delete activé — calcul des suppressions logiques",
                    table_name,
                )
                self._validate_target_columns(
                    mapping,
                    self._SOFT_DELETE_REQUIRED_COLUMNS,
                    step_name="soft delete",
                )
                # Compare les clés source vs cible pour marquer les lignes
                # disparues (voir ``SoftDeleteProcessor``).
                sd_metrics = self._soft_deleter.apply(
                    df_valid, mapping, contract, sequence_id, processing_id
                )
                rows_deleted = sd_metrics.rows_deleted
                _log.info(
                    "[Pipeline][%s] Soft delete terminé — %d ligne(s) marquée(s) supprimée(s)",
                    table_name,
                    rows_deleted,
                )

            # ----------------------------------------------------------------
            # ÉTAPE 6 — Écriture cible (SCD2 ou SCD1/full)
            # ----------------------------------------------------------------
            if mapping.scd_type == 2:
                # SCD2 : historisation via ``SCD2Processor`` (2-step MERGE
                # + INSERT append avec hash SHA-256).
                _log.info("[Pipeline][%s] Écriture SCD type 2", table_name)
                self._validate_target_columns(
                    mapping,
                    self._SCD2_REQUIRED_COLUMNS,
                    step_name="SCD2",
                )
                write_metrics = self._scd2.write(
                    df_valid, mapping, contract, sequence_id, processing_id
                )
            else:
                # SCD1 ou full : écrasement / MERGE upsert simple via ``Writer``.
                _log.info("[Pipeline][%s] Écriture standard (overwrite/merge)", table_name)
                write_metrics = self._writer.write(
                    df_valid, mapping, contract, sequence_id, processing_id
                )

            _log.info(
                "[Pipeline][%s] Écriture terminée — insérées=%d, mises à jour=%d, supprimées=%d",
                table_name,
                write_metrics.rows_inserted,
                write_metrics.rows_updated,
                rows_deleted,
            )

            # Construction du résultat final avec TOUTES les métriques.
            # Le ``ProcessingResult`` est immuable (frozen dataclass) et
            # sérialisable pour le log Delta.
            result = ProcessingResult(
                table_name=table_name,
                status="success",
                rows_read=rows_read,
                rows_valid=rows_valid,
                rows_rejected=rows_rejected,
                rows_inserted=write_metrics.rows_inserted,
                rows_updated=write_metrics.rows_updated,
                rows_deleted=rows_deleted,
            )

        except ContractViolationError as e:
            # Erreur métier attendue : les données source ne respectent pas
            # le schéma du contract. On la traite spécifiquement pour
            # produire un message d'erreur clair (sans le préfixe du type).
            _log.error("[Pipeline][%s] Violation du contract : %s", table_name, e)
            result = ProcessingResult(table_name=table_name, status="failure", error_message=str(e))

        except Exception as e:
            # Erreur inattendue : on capture pour garantir l'écriture du log
            # de fin (pas de fuite silencieuse). Le message inclut le type
            # d'exception pour faciliter le diagnostic.
            _log.exception("[Pipeline][%s] Erreur inattendue : %s", table_name, e)
            result = ProcessingResult(
                table_name=table_name,
                status="failure",
                error_message=f"{type(e).__name__}: {e}",
            )

        finally:
            # Libération du cache Spark quel que soit le statut (succès ou
            # échec, capturé ou levé). ``unpersist()`` sans blocking est
            # asynchrone et sans effet si le DataFrame n'a pas été
            # effectivement mis en cache. On protège l'appel par un
            # try/except pour ne pas masquer une autre exception.
            if df_cached is not None:
                try:
                    df_cached.unpersist()
                except Exception:
                    _log.debug("[Pipeline][%s] unpersist() a échoué (ignoré)", table_name)

        # Écriture de l'événement de fin dans le log lakehouse, quel que soit
        # le statut. C'est CRITIQUE : sans cet append, le run apparaîtrait
        # comme "toujours en cours" dans les vues d'observabilité.
        _log.info(
            "[Pipeline][%s] Enregistrement de l'événement de fin — statut=%s",
            table_name,
            result.status,
        )
        self._logger.log_processing_end(
            sequence_id, load_id, processing_id, table_name, "INGESTION", result
        )
        return result

    def _validate_target_columns(
        self,
        mapping: TableMapping,
        required_columns: frozenset[str],
        step_name: str,
    ) -> None:
        """Valide les colonnes requises par une étape sur une cible existante."""
        target_table = f"{self._lakehouse}.{mapping.target_schema}.{mapping.target_table}"
        if not self._spark.catalog.tableExists(target_table):
            return

        target_columns = {column.lower() for column in self._spark.table(target_table).columns}
        missing_columns = sorted(required_columns - target_columns)
        if not missing_columns:
            return

        missing_display = ", ".join(missing_columns)
        raise ValueError(
            f"Table cible '{target_table}' incompatible avec l'étape {step_name} : "
            f"colonne(s) requise(s) manquante(s) [{missing_display}]. "
            "Migrez ou recréez explicitement la cible avant de relancer le pipeline."
        )

    def transform(
        self, df: DataFrame, mapping: TableMapping, contract: DataContract
    ) -> DataFrame:
        """Hook surchargeable exclusivement pour les transformations BDP.

        Par défaut : passthrough (identity). C'est le point d'extension
        principal pour les BDP qui doivent appliquer une logique métier
        (jointures, calculs, agrégations…).

        Args:
            df: DataFrame BDP lu depuis la vue DSO, avant validation du contrat.
            mapping: Configuration de la table (peut porter des paramètres
                custom exploitables par la sous-classe).
            contract: Contrat décrivant la sortie métier BDP.

        Returns:
            DataFrame transformé. Doit conserver un schéma compatible avec
            la cible (nommage des colonnes attendues côté SCD2).

        Exemple:
            >>> class MyBDPPipeline(Pipeline):
            ...     def transform(self, df, mapping, contract):
            ...         # Conversion euro → dollar
            ...         return df.withColumn("montant_usd", col("montant_eur") * lit(1.10))

        """
        # Implémentation par défaut : aucune transformation.
        # ``debug`` (pas ``info``) pour ne pas polluer les logs quand la
        # sous-classe ne surcharge pas cette méthode.
        _log.debug(
            "[Pipeline][%s] transform() — passthrough (aucune transformation)",
            mapping.name,
        )
        return df

    def _apply_column_mapping(self, df: DataFrame, contract: DataContract) -> DataFrame:
        """Renomme les colonnes source vers les noms cibles définis dans le contract.

        Le contract définit ``ColumnContract.source_name`` (nom dans la source
        brute) et ``ColumnContract.name`` (nom cible propre). Cette méthode
        applique le renommage seulement quand les noms diffèrent (évite les
        no-op).

        Colonnes absentes du DataFrame : warning + ignorées silencieusement
        (défensif — cas d'une évolution de schéma source).

        Args:
            df: DataFrame source à renommer.
            contract: Contract portant les paires source_name / name.

        Returns:
            DataFrame avec les colonnes renommées.

        Exemple:
            contract.columns = [ColumnContract(source_name="GroupeID", name="groupe_id"), ...]
            → df.columns : ["GroupeID", "Libellé"]
            → after      : ["groupe_id", "Libellé"]

        """
        renamed_count = 0
        for col_contract in contract.columns:
            # Renommage seulement si les noms diffèrent (skip no-op).
            if col_contract.source_name != col_contract.name:
                if col_contract.source_name in df.columns:
                    _log.debug(
                        "[Pipeline] Renommage colonne : '%s' → '%s'",
                        col_contract.source_name,
                        col_contract.name,
                    )
                    df = df.withColumnRenamed(col_contract.source_name, col_contract.name)
                    renamed_count += 1
                else:
                    # Colonne source absente du DataFrame : warning + skip.
                    # Cas fréquent en début de projet ou après une évolution
                    # de schéma non répercutée dans le contract.
                    _log.warning(
                        "[Pipeline] Colonne source '%s' absente du DataFrame — renommage ignoré",
                        col_contract.source_name,
                    )
        _log.info(
            "[Pipeline] Mapping de colonnes appliqué — %d colonne(s) renommée(s)",
            renamed_count,
        )
        return df
