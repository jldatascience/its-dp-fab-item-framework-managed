"""Contracts — Validation du data contract."""
