"""Validation du Data Contract — vérifie structure, types et clé fonctionnelle.

Rôle dans le pipeline
---------------------
Cette validation est **bloquante et pré-DQ** : elle intervient juste après la
lecture de la source et AVANT tout contrôle de qualité. Si le contract est
violé, ``ContractViolationError`` est levée et le pipeline s'arrête (le
``Pipeline`` capture l'exception pour logger le ``processing_end`` en
``failure``, puis re-propage).

Distinction contract vs DQ
--------------------------
- **Contract** (ce module) → **schéma** : présence des colonnes, types, clé
  fonctionnelle. Violation = erreur bloquante (la source ne correspond pas au
  format attendu, on refuse de traiter).
- **DQ** (module ``quality/checks.py``) → **contenu** : NULL, format regex,
  doublons. Violation = ligne rejetée (on continue avec les lignes valides).

Utilisé pour les **ADP** avant la DQ et pour les **BDP** après ``transform()``.
"""

from __future__ import annotations

import logging
from typing import ClassVar

from pyspark.sql import DataFrame

from dp_framework.config.models import DataContract

# Logger Python standard — les traces sortent dans la sortie du notebook Fabric.
_log = logging.getLogger(__name__)


class ContractViolationError(Exception):
    """Levée quand le Data Contract est violé (erreur bloquante).

    Le ``Pipeline`` capture spécifiquement cette exception pour distinguer
    une violation de contract (attendue = mauvaise source) d'une exception
    inattendue (bug technique) dans les logs.
    """


class ContractValidator:
    """Valide un DataFrame contre le data contract YAML.

    Contrôles effectués (tous bloquants) :

    1. **Clé fonctionnelle** : au moins une colonne ``functional_key=True``
       doit être définie dans le contract (sinon impossible d'appliquer
       SCD2 ou l'unicité DQ).
    2. **Présence** : toutes les colonnes du contract doivent exister dans
       le DataFrame source (comparaison case-insensitive pour tolérer les
       différences de casse ``Groupementgup`` vs ``groupementgup``).
    3. **Types** : le type Spark réel doit être compatible avec le type
       déclaré dans le contract. La compatibilité utilise des **groupes**
       (ex : ``"Integer"`` du YAML accepte ``"int"``, ``"integer"``,
       ``"smallint"``, etc. côté Spark).

    Toutes les violations sont accumulées puis levées d'un coup pour
    permettre à l'utilisateur de tout corriger en un passage.
    """

    # ------------------------------------------------------------------
    # Groupes de compatibilité de types Spark
    # ------------------------------------------------------------------
    # Utilisés par ``_types_compatible()`` pour accepter plusieurs variantes
    # d'un même type sémantique.
    #
    # Structure : ``{ type_déclaré_dans_le_YAML : ensemble des types Spark
    # réels acceptés }``.
    #
    # - La CLÉ est le nom "canonique" tel qu'il peut apparaître dans le YAML
    #   (ex : ``"integer"`` en camelCase-insensitive, ``"datetime"`` alias
    #   métier).
    # - Les VALEURS sont les types Spark renvoyés par ``dataType.simpleString()``
    #   considérés comme équivalents.
    # - Les alias métier sont inclus (ex : ``"datetime"`` → groupe ``"timestamp"``).
    _TYPE_GROUPS: ClassVar[dict[str, set[str]]] = {
        "string": {"string", "varchar", "char"},
        "integer": {"int", "integer", "smallint", "tinyint", "short"},
        "bigint": {"bigint", "long"},
        "long": {"long", "bigint"},
        "double": {"double", "float", "decimal"},
        "date": {"date"},
        "timestamp": {"timestamp", "timestamp_ntz"},
        "datetime": {"timestamp", "timestamp_ntz"},
        "boolean": {"boolean"},
    }

    def validate(self, df: DataFrame, contract: DataContract) -> None:
        """Valide le DataFrame contre le contract.

        Effectue tous les contrôles (présence, types, clé fonctionnelle) et
        **accumule les violations** avant de lever une seule exception. Cela
        permet à l'utilisateur de corriger l'ensemble des problèmes en un
        passage plutôt que d'itérer une erreur à la fois.

        Args:
            df: DataFrame à valider (typiquement la source lue par ``SourceReader``).
            contract: DataContract chargé depuis le YAML.

        Raises:
            ContractViolationError: Si au moins une violation est détectée.
                Le message contient toutes les violations formatées en liste.

        Exemple d'usage:
            >>> validator = ContractValidator()
            >>> try:
            ...     validator.validate(df_source, contract)
            ... except ContractViolationError as e:
            ...     print(f"Sources non conformes: {e}")

        Exemple de message d'erreur:
            Contract violation pour 'employee' (2 violation(s)):
              - Colonne requise manquante: 'employee_id'
              - Type incompatible pour 'salary': attendu 'Double', trouvé 'string'

        """
        _log.info(
            "[ContractValidator] Validation du contract '%s' — %d colonne(s) déclarée(s)",
            contract.table_name,
            len(contract.columns),
        )

        # Un contrat vide ne peut garantir ni le schéma ni la clé primaire.
        if not contract.columns:
            raise ContractViolationError(
                f"Contract violation pour '{contract.table_name}' (1 violation(s)):\n"
                "  - Aucune colonne définie dans le contract"
            )

        # Accumulateur : on collecte toutes les violations avant de lever
        # l'exception pour donner un feedback complet à l'utilisateur.
        violations: list[str] = []

        # ----- Contrôle 1 — Au moins une clé fonctionnelle -----
        # Sans clé fonctionnelle, impossible d'appliquer SCD2 ou l'unicité DQ.
        if not contract.functional_keys:
            violations.append("Aucune clé fonctionnelle définie (functional_key=true)")

        # Maps case-insensitive : les noms de colonnes Spark peuvent différer
        # en casse entre la source et le contract (ex : "EmpID" vs "empid").
        # On indexe par lower() pour comparer sans se soucier de la casse.
        df_columns_lower = {c.lower(): c for c in df.columns}
        df_schema_map = {f.name.lower(): f for f in df.schema.fields}

        for col_contract in contract.columns:
            col_lower = col_contract.source_name.lower()

            # ----- Contrôle 2 — Présence de la colonne -----
            if col_lower not in df_columns_lower:
                violations.append(f"Colonne requise manquante: '{col_contract.source_name}'")
                # ``continue`` : inutile de vérifier le type d'une colonne absente.
                continue

            # ----- Contrôle 3 — Compatibilité du type Spark -----
            df_field = df_schema_map.get(col_lower)
            if df_field:
                # ``simpleString()`` renvoie ex : "int", "string", "decimal(18,2)".
                # Le lowercase permet une comparaison uniforme.
                actual_type = df_field.dataType.simpleString().lower()
                expected_type = col_contract.type.lower().strip()
                if not self._types_compatible(actual_type, expected_type):
                    violations.append(
                        f"Type incompatible pour '{col_contract.source_name}': "
                        f"attendu '{col_contract.type}', trouvé '{actual_type}'",
                    )

        # ----- Rapport final -----
        if violations:
            _log.error(
                "[ContractValidator] %d violation(s) détectée(s) pour '%s' : %s",
                len(violations),
                contract.table_name,
                violations,
            )
            # Formatage lisible : titre + une violation par ligne indentée.
            msg = (
                f"Contract violation pour '{contract.table_name}' "
                f"({len(violations)} violation(s)):\n"
            )
            msg += "\n".join(f"  - {v}" for v in violations)
            raise ContractViolationError(msg)

        _log.info(
            "[ContractValidator] Contract '%s' validé sans violation",
            contract.table_name,
        )

    def _types_compatible(self, actual: str, expected: str) -> bool:
        """Vérifie la compatibilité entre le type Spark réel et le type déclaré.

        Deux types sont compatibles s'ils appartiennent au même groupe de
        ``_TYPE_GROUPS`` ou s'ils sont strictement identiques. On n'utilise
        volontairement pas ``startswith`` en fallback : cela causerait des faux
        positifs (ex. ``"bool"`` matcherait ``"boolean"`` par préfixe, ou
        ``"int"`` matcherait ``"interval"``).

        Args:
            actual: Type Spark réel (issu de ``dataType.simpleString().lower()``).
                Ex : ``"int"``, ``"string"``, ``"decimal(18,2)"``.
            expected: Type déclaré dans le YAML (lowercase).
                Ex : ``"integer"``, ``"string"``, ``"double"``.

        Returns:
            ``True`` si les types sont compatibles, ``False`` sinon.

        Exemples:
            >>> v = ContractValidator()
            >>> v._types_compatible("int", "integer")      # même groupe
            True
            >>> v._types_compatible("decimal(18,2)", "double")  # decimal → double
            True
            >>> v._types_compatible("boolean", "bool")     # ne match plus (fix bug)
            False
            >>> v._types_compatible("string", "date")      # groupes différents
            False

        """
        expected_lower = expected.lower()
        # Normalise les types paramétrés (ex. "decimal(18,2)" → "decimal")
        # pour permettre la correspondance exacte dans les sets de ``_TYPE_GROUPS``.
        if "(" in actual:
            actual = actual[: actual.index("(")]
        for group_name, group_types in self._TYPE_GROUPS.items():
            # Le type déclaré appartient à ce groupe si :
            #  - c'est le nom canonique du groupe (ex : "integer"), OU
            #  - il figure dans les alias (ex : "int", "smallint").
            if expected_lower == group_name or expected_lower in group_types:
                return actual in group_types or actual == group_name
        # Aucun groupe déclaré : exiger une correspondance exacte pour éviter
        # les faux positifs (pas de startswith).
        return actual == expected_lower
