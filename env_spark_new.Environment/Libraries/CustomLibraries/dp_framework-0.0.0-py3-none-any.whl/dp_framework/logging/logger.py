"""Logger — Logging événementiel append-only dans le schéma ``observability``.

Rôle dans le pipeline
---------------------
Point d'entrée pour tracer TOUS les événements du pipeline dans trois tables
Delta immuables :

- **``log_sequence``** (niveau 1) : suivi d'une exécution globale
  (ex : "nightly ADP", "hourly BDP").
- **``log_load``** (niveau 2) : suivi d'un chargement complet d'un objet
  (table) à l'intérieur d'une séquence — un rechargement complet de l'objet
  crée un nouveau ``load_id``.
- **``log_processing``** (niveau 3) : suivi d'une étape technique d'un
  chargement (ex : INGESTION) — un retry d'étape crée un nouveau
  ``processing_id`` mais réutilise le même ``load_id``.

Principes de conception
-----------------------
Chaque changement d'état génère un **nouvel événement immuable** (Delta
append). **Aucun UPDATE, MERGE ou verrouillage** n'est utilisé — c'est un
pattern d'**event sourcing** qui garantit :

- Zéro contention concurrentielle (100% append-only).
- Traçabilité complète (on garde tous les états intermédiaires).
- Simplicité de reprise (rejouer les événements suffit).

L'état "actuel" d'une séquence, d'un chargement ou d'un processing s'obtient
via des vues SQL (voir ``sql/views/``) qui agrègent les événements par
``sequence_id``, ``load_id`` ou ``processing_id`` et prennent le plus récent.

Cycle de vie type (séquence / load / processing)
-------------------------------------------------
    event_type=STARTED   → status=running   (début)
    event_type=COMPLETED → status=success   (fin sans erreur)
    event_type=COMPLETED → status=failure   (fin avec erreur)

Cohérence applicative (niveau Load)
------------------------------------
``log_load_end`` ne fait pas confiance au statut proposé par l'appelant : le
statut final est **dérivé** des compteurs ``processings_count`` /
``processings_success`` / ``processings_failed`` :

- ``success + failed > count`` → état impossible, ``ValueError`` (bug appelant).
- ``success + failed < count`` → incohérence applicative (étape jamais
  démarrée/terminée) — n'est **pas** bloquant, le statut est forcé à
  ``"failure"`` et ``error_message`` est enrichi.
- ``success + failed == count`` → statut dérivé de ``failed > 0``.

Le blocage inter-objets (dépendances fonctionnelles entre chargements) reste
entièrement porté par l'orchestration Fabric (liens d'activité "On
Success"/"On Completion") — ``Logger`` ne bloque jamais l'exécution du
pipeline, il ne fait qu'observer et enregistrer.

Purge
-----
Une seule opération DELETE est autorisée : la **purge planifiée** basée sur
``event_time`` (rétention configurable, appelée depuis
``nb_purge_logs.py``). Elle ne doit pas être appelée en concurrence avec
des inserts.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime, timedelta

from delta.tables import DeltaTable
from pyspark.sql import Row, SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import (
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from dp_framework.config.models import ProcessingResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valeurs autorisées — validées par ``_validate_event`` avant chaque insert.
# Tout écart lève une ``ValueError`` explicite, évite les bugs silencieux
# (typo dans un status ⇒ requête agrégée fausse).
# ---------------------------------------------------------------------------

# ``STARTED`` = début d'un cycle, ``COMPLETED`` = fin (succès OU échec).
_VALID_EVENT_TYPES: frozenset[str] = frozenset({"STARTED", "COMPLETED"})

# ``running`` = en cours, ``success`` = terminé OK, ``failure`` = terminé KO.
_VALID_STATUSES: frozenset[str] = frozenset({"running", "success", "failure"})

# Correspondance statut fonctionnel → ``(event_type, log_status)``.
# Utilisé par ``end_sequence``, ``log_load_end`` et ``log_processing_end``
# pour convertir le statut fonctionnel du pipeline en couple event_type/status log.
_RESULT_TO_EVENT: dict[str, tuple[str, str]] = {
    "success": ("COMPLETED", "success"),
    "failure": ("COMPLETED", "failure"),
}

# Couples event_type/status cohérents avec le cycle de vie événementiel.
_VALID_EVENT_STATUS_PAIRS: frozenset[tuple[str, str]] = frozenset(
    {
        ("STARTED", "running"),
        ("COMPLETED", "success"),
        ("COMPLETED", "failure"),
    },
)


def _validate_event(event_type: str, status: str) -> None:
    """Vérifie qu'``event_type``, ``status`` et leur combinaison sont autorisés.

    Défense en profondeur : chaque insert log passe par cette fonction pour
    éviter qu'un caller (typo, bug) ne pollue les tables avec une valeur
    inattendue qui casserait les vues SQL et les dashboards.

    Raises:
        ValueError: Si l'une des valeurs, ou leur combinaison, est invalide.

    """
    if event_type not in _VALID_EVENT_TYPES:
        raise ValueError(
            f"event_type invalide : '{event_type}'. "
            f"Valeurs autorisées : {sorted(_VALID_EVENT_TYPES)}.",
        )
    if status not in _VALID_STATUSES:
        raise ValueError(
            f"status invalide : '{status}'. Valeurs autorisées : {sorted(_VALID_STATUSES)}.",
        )
    if (event_type, status) not in _VALID_EVENT_STATUS_PAIRS:
        raise ValueError(
            "Combinaison event_type/status invalide : "
            f"event_type='{event_type}', status='{status}'. "
            f"Combinaisons autorisées : {sorted(_VALID_EVENT_STATUS_PAIRS)}.",
        )


def _validate_non_empty(name: str, value: str) -> None:
    """Lève une ``ValueError`` si ``value`` est vide/None.

    Défense en profondeur, même logique que ``_validate_event`` : un caller
    (typo, bug) ne doit pas pouvoir écrire une ligne avec un identifiant vide.
    """
    if not value:
        raise ValueError(f"{name} ne peut pas être vide.")


def _validate_non_negative(name: str, value: int) -> None:
    """Lève une ``ValueError`` si ``value`` est strictement négatif."""
    if value < 0:
        raise ValueError(f"{name} doit être positif ou nul, reçu : {value}.")


def _validate_counts_not_exceeding(count: int, success: int, failed: int, label: str) -> None:
    """Vérifie que ``success + failed`` ne dépasse jamais ``count``.

    ``success + failed > count`` est un état impossible (bug appelant) et
    doit toujours lever — contrairement à ``success + failed < count`` qui
    est une incohérence applicative gérée séparément par l'appelant
    (ex : ``log_load_end``) sans lever d'exception.
    """
    _validate_non_negative(f"{label}_count", count)
    _validate_non_negative(f"{label}_success", success)
    _validate_non_negative(f"{label}_failed", failed)
    if success + failed > count:
        raise ValueError(
            f"Compteurs incohérents : {label}_success + {label}_failed "
            f"({success + failed}) > {label}_count ({count}).",
        )


class Logger:
    """Gère le logging événementiel à 3 niveaux dans le schéma ``observability``.

    Les tables ``log_sequence``, ``log_load`` et ``log_processing`` sont des
    journaux immuables en mode **append-only**. Chaque transition d'état
    ajoute une nouvelle ligne. Aucun UPDATE, MERGE ou DELETE n'est effectué
    (hors ``purge()`` planifiée).

    Niveau 1 — ``log_sequence`` (flux global par séquence) :
        event_id, sequence_id, sequence_name, event_type, event_time,
        status, objects_count, objects_success, objects_failed, error_message

    Niveau 2 — ``log_load`` (chargement complet d'un objet) :
        event_id, load_id, sequence_id, object_name, event_type, event_time,
        status, processings_count, processings_success, processings_failed,
        rows_read, rows_valid, rows_rejected, rows_inserted, rows_updated,
        rows_deleted, error_message

    Niveau 3 — ``log_processing`` (étape technique d'un chargement) :
        event_id, processing_id, load_id, sequence_id, object_name,
        processing_name, event_type, event_time, status, rows_read,
        rows_valid, rows_rejected, rows_inserted, rows_updated,
        rows_deleted, error_message

    Exemple de cycle complet:
        >>> logger.start_sequence(sequence_id, "nom_sequence")
        >>> # ... pour chaque objet ...
        >>> load_id = logger.log_load_start(sequence_id, object_name, processings_count=1)
        >>> processing_id = logger.log_processing_start(
        ...     sequence_id, load_id, object_name, "INGESTION",
        ... )
        >>> logger.log_processing_end(
        ...     sequence_id, load_id, processing_id, object_name, "INGESTION", result,
        ... )
        >>> logger.log_load_end(
        ...     sequence_id, load_id, object_name,
        ...     processings_count=1, processings_success=1, processings_failed=0,
        ...     result=result,
        ... )
        >>> logger.end_sequence(sequence_id, "nom_sequence", "success",
        ...                      objects_count=1, objects_success=1, objects_failed=0)
    """

    def __init__(self, spark: SparkSession, lakehouse: str) -> None:
        """Instancie le Logger sur un lakehouse donné.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse cible (ex : ``"lh_storage"``).
                Le schéma cible est toujours ``{lakehouse}.observability``.

        """
        self._spark = spark
        self._lakehouse = lakehouse
        # Convention : les logs sont TOUJOURS dans le schéma ``observability``
        # du lakehouse (nom hardcodé pour éviter les configs divergentes
        # entre projets).
        self._obs_schema = f"{lakehouse}.observability"

    # ------------------------------------------------------------------
    # Schémas Delta — définis en Python pour garantir la cohérence entre
    # la création (nb_init_metadata) et les inserts (ici).
    # ------------------------------------------------------------------

    def _sequence_schema(self) -> StructType:
        """Retourne le schéma StructType de la table ``log_sequence``.

        Ce schéma est utilisé pour créer un DataFrame typé avant l'append
        Delta, garantissant que chaque insert respecte le contrat.
        """
        return StructType(
            [
                StructField("event_id", StringType(), False),
                StructField("sequence_id", StringType(), False),
                StructField("sequence_name", StringType(), False),
                StructField("event_type", StringType(), False),
                StructField("event_time", TimestampType(), False),
                StructField("status", StringType(), False),
                StructField("objects_count", LongType(), False),
                StructField("objects_success", LongType(), False),
                StructField("objects_failed", LongType(), False),
                StructField("error_message", StringType(), True),
            ],
        )

    def _load_schema(self) -> StructType:
        """Retourne le schéma StructType de la table ``log_load``.

        Colonnes de métriques non-nullables : on veut 0 plutôt que null pour
        simplifier les agrégations (``SUM``, ``AVG``).
        """
        return StructType(
            [
                StructField("event_id", StringType(), False),
                StructField("load_id", StringType(), False),
                StructField("sequence_id", StringType(), False),
                StructField("object_name", StringType(), False),
                StructField("event_type", StringType(), False),
                StructField("event_time", TimestampType(), False),
                StructField("status", StringType(), False),
                StructField("processings_count", LongType(), False),
                StructField("processings_success", LongType(), False),
                StructField("processings_failed", LongType(), False),
                StructField("rows_read", LongType(), False),
                StructField("rows_valid", LongType(), False),
                StructField("rows_rejected", LongType(), False),
                StructField("rows_inserted", LongType(), False),
                StructField("rows_updated", LongType(), False),
                StructField("rows_deleted", LongType(), False),
                StructField("error_message", StringType(), True),
            ],
        )

    def _processing_schema(self) -> StructType:
        """Retourne le schéma StructType de la table ``log_processing``.

        Colonnes de métriques (``rows_*``) non-nullables : on veut 0 plutôt
        que null pour simplifier les agrégations (``SUM``, ``AVG``).
        """
        return StructType(
            [
                StructField("event_id", StringType(), False),
                StructField("processing_id", StringType(), False),
                StructField("load_id", StringType(), False),
                StructField("sequence_id", StringType(), False),
                StructField("object_name", StringType(), False),
                StructField("processing_name", StringType(), False),
                StructField("event_type", StringType(), False),
                StructField("event_time", TimestampType(), False),
                StructField("status", StringType(), False),
                StructField("rows_read", LongType(), False),
                StructField("rows_valid", LongType(), False),
                StructField("rows_rejected", LongType(), False),
                StructField("rows_inserted", LongType(), False),
                StructField("rows_updated", LongType(), False),
                StructField("rows_deleted", LongType(), False),
                StructField("error_message", StringType(), True),
            ],
        )

    # ------------------------------------------------------------------
    # Helper d'écriture Delta
    # ------------------------------------------------------------------

    def _append(self, rows: list[Row], schema: StructType, target: str) -> None:
        """Crée un DataFrame depuis les Rows fournies et l'appende dans la table Delta cible.

        - ``mode("append")`` : ajout garanti (jamais d'écrasement).
        - Schéma strict : pas de ``mergeSchema`` — le schéma des tables
          d'observabilité est figé, toute évolution doit passer par une
          migration explicite (contrairement aux tables de rejets).

        Args:
            rows: Lignes à insérer (une par événement, typiquement 1 seule).
            schema: Schéma StructType attendu (garantit le typage).
            target: Nom complet de la table Delta cible.

        """
        df = self._spark.createDataFrame(rows, schema=schema)
        df.write.format("delta").mode("append").saveAsTable(target)

    # ------------------------------------------------------------------
    # Niveau 1 — Séquence
    # ------------------------------------------------------------------

    def start_sequence(
        self,
        sequence_id: str,
        sequence_name: str,
    ) -> None:
        """Enregistre le démarrage d'une séquence (event_type=STARTED).

        Args:
            sequence_id: Identifiant unique de la séquence.
            sequence_name: Nom lisible de la séquence.

        """
        target = f"{self._obs_schema}.log_sequence"
        _validate_non_empty("sequence_id", sequence_id)
        _validate_non_empty("sequence_name", sequence_name)
        _validate_event("STARTED", "running")

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                sequence_id=sequence_id,
                sequence_name=sequence_name,
                event_type="STARTED",
                event_time=datetime.now(UTC),
                status="running",
                objects_count=0,
                objects_success=0,
                objects_failed=0,
                error_message=None,
            )
            self._append([row], self._sequence_schema(), target)
            logger.info(
                "Séquence '%s' démarrée — sequence_id=%s.",
                sequence_name,
                sequence_id,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement du démarrage de la séquence "
                "'%s' (sequence_id=%s).",
                sequence_name,
                sequence_id,
            )

    def end_sequence(
        self,
        sequence_id: str,
        sequence_name: str,
        status: str,
        objects_count: int,
        objects_success: int,
        objects_failed: int,
        error_message: str | None = None,
    ) -> None:
        """Enregistre la fin d'une séquence (event_type=COMPLETED).

        Args:
            sequence_id: Identifiant unique de la séquence.
            sequence_name: Nom lisible de la séquence.
            status: Statut final — 'success' ou 'failure'.
            objects_count: Nombre total d'objets traités.
            objects_success: Nombre d'objets traités avec succès.
            objects_failed: Nombre d'objets en échec.
            error_message: Message d'erreur optionnel.

        """
        target = f"{self._obs_schema}.log_sequence"

        _validate_non_empty("sequence_id", sequence_id)
        _validate_non_empty("sequence_name", sequence_name)
        _validate_counts_not_exceeding(objects_count, objects_success, objects_failed, "objects")

        if status not in _RESULT_TO_EVENT:
            raise ValueError(
                f"status invalide pour end_sequence : '{status}'. "
                f"Valeurs autorisées : {sorted(_RESULT_TO_EVENT)}.",
            )

        event_type, mapped_status = _RESULT_TO_EVENT[status]
        _validate_event(event_type, mapped_status)

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                sequence_id=sequence_id,
                sequence_name=sequence_name,
                event_type=event_type,
                event_time=datetime.now(UTC),
                status=mapped_status,
                objects_count=objects_count,
                objects_success=objects_success,
                objects_failed=objects_failed,
                error_message=error_message,
            )
            self._append([row], self._sequence_schema(), target)
            logger.info(
                "Séquence sequence_id=%s terminée — event_type=%s, statut=%s, "
                "objets=%d (succès=%d, échecs=%d).",
                sequence_id,
                event_type,
                mapped_status,
                objects_count,
                objects_success,
                objects_failed,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement de la fin de la séquence "
                "(sequence_id=%s).",
                sequence_id,
            )

    # ------------------------------------------------------------------
    # Niveau 2 — Load (chargement complet d'un objet)
    # ------------------------------------------------------------------

    def log_load_start(
        self,
        sequence_id: str,
        object_name: str,
        processings_count: int,
    ) -> str:
        """Enregistre le démarrage du chargement d'un objet (event_type=STARTED).

        Args:
            sequence_id: Identifiant de la séquence parente.
            object_name: Nom de l'objet en cours de chargement.
            processings_count: Nombre d'étapes techniques attendues pour ce
                chargement (déclaré par l'appelant/orchestrateur).

        Returns:
            load_id: Identifiant unique à passer à log_processing_start/end
                et à log_load_end.

        """
        target = f"{self._obs_schema}.log_load"
        _validate_non_empty("sequence_id", sequence_id)
        _validate_non_empty("object_name", object_name)
        _validate_non_negative("processings_count", processings_count)
        _validate_event("STARTED", "running")

        load_id = str(uuid.uuid4())

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                load_id=load_id,
                sequence_id=sequence_id,
                object_name=object_name,
                event_type="STARTED",
                event_time=datetime.now(UTC),
                status="running",
                processings_count=processings_count,
                processings_success=0,
                processings_failed=0,
                rows_read=0,
                rows_valid=0,
                rows_rejected=0,
                rows_inserted=0,
                rows_updated=0,
                rows_deleted=0,
                error_message=None,
            )
            self._append([row], self._load_schema(), target)
            logger.info(
                "Chargement démarré pour l'objet '%s' — load_id=%s, sequence_id=%s.",
                object_name,
                load_id,
                sequence_id,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement du démarrage du chargement "
                "de l'objet '%s' (sequence_id=%s).",
                object_name,
                sequence_id,
            )

        return load_id

    def log_load_end(
        self,
        sequence_id: str,
        load_id: str,
        object_name: str,
        processings_count: int,
        processings_success: int,
        processings_failed: int,
        result: ProcessingResult | None = None,
        error_message: str | None = None,
    ) -> None:
        """Enregistre la fin du chargement d'un objet (event_type=COMPLETED).

        Le statut final n'est **pas** un paramètre d'entrée : il est dérivé
        des compteurs pour empêcher un notebook appelant d'imposer un statut
        incohérent avec l'état réel des processings (défense en profondeur,
        même logique que ``_validate_event``) :

        - ``processings_success + processings_failed > processings_count``
          → état impossible, lève ``ValueError``.
        - ``processings_success + processings_failed < processings_count``
          → incohérence applicative (étape jamais démarrée/terminée) — ne
          lève pas, force ``status="failure"`` et enrichit ``error_message``.
        - Sinon → statut dérivé de ``processings_failed > 0``.

        Args:
            sequence_id: Identifiant de la séquence parente.
            load_id: Identifiant retourné par log_load_start.
            object_name: Nom de l'objet chargé.
            processings_count: Nombre d'étapes techniques attendues.
            processings_success: Nombre d'étapes terminées avec succès
                (dédoublonné par étape — un retry ne compte qu'une fois).
            processings_failed: Nombre d'étapes en échec (dédoublonné).
            result: Résultat de l'étape d'ingestion, s'il est disponible —
                alimente les métriques ``rows_*`` du chargement.
            error_message: Message d'erreur optionnel, complété si une
                incohérence applicative est détectée.

        """
        target = f"{self._obs_schema}.log_load"

        _validate_non_empty("sequence_id", sequence_id)
        _validate_non_empty("load_id", load_id)
        _validate_non_empty("object_name", object_name)
        _validate_counts_not_exceeding(
            processings_count,
            processings_success,
            processings_failed,
            "processings",
        )

        if processings_success + processings_failed < processings_count:
            missing = processings_count - processings_success - processings_failed
            status = "failure"
            note = (
                f"{missing} étape(s) technique(s) manquante(s) sur "
                f"{processings_count} attendue(s) "
                f"(success={processings_success}, failed={processings_failed})."
            )
            error_message = f"{error_message} | {note}" if error_message else note
            logger.warning(
                "Incohérence détectée pour load_id=%s (object_name=%s) : %s",
                load_id,
                object_name,
                note,
            )
        else:
            status = "failure" if processings_failed > 0 else "success"

        event_type, mapped_status = _RESULT_TO_EVENT[status]
        _validate_event(event_type, mapped_status)

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                load_id=load_id,
                sequence_id=sequence_id,
                object_name=object_name,
                event_type=event_type,
                event_time=datetime.now(UTC),
                status=mapped_status,
                processings_count=processings_count,
                processings_success=processings_success,
                processings_failed=processings_failed,
                rows_read=result.rows_read if result else 0,
                rows_valid=result.rows_valid if result else 0,
                rows_rejected=result.rows_rejected if result else 0,
                rows_inserted=result.rows_inserted if result else 0,
                rows_updated=result.rows_updated if result else 0,
                rows_deleted=result.rows_deleted if result else 0,
                error_message=error_message,
            )
            self._append([row], self._load_schema(), target)
            logger.info(
                "Chargement terminé pour l'objet '%s' — load_id=%s, "
                "sequence_id=%s, event_type=%s, statut=%s.",
                object_name,
                load_id,
                sequence_id,
                event_type,
                mapped_status,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement de la fin du chargement "
                "de l'objet '%s' (load_id=%s, sequence_id=%s).",
                object_name,
                load_id,
                sequence_id,
            )

    # ------------------------------------------------------------------
    # Niveau 3 — Processing (étape technique d'un chargement)
    # ------------------------------------------------------------------

    def log_processing_start(
        self,
        sequence_id: str,
        load_id: str,
        object_name: str,
        processing_name: str,
    ) -> str:
        """Enregistre le démarrage d'une étape technique (event_type=STARTED).

        Doit être appelé immédiatement avant le début de l'étape pour
        rendre visible l'état 'running' en temps réel dans les logs.

        Args:
            sequence_id: Identifiant de la séquence parente.
            load_id: Identifiant du chargement parent.
            object_name: Nom de l'objet en cours de traitement.
            processing_name: Nom de l'étape technique (ex : "INGESTION").

        Returns:
            processing_id: Identifiant unique à passer à log_processing_end.

        """
        target = f"{self._obs_schema}.log_processing"
        _validate_non_empty("sequence_id", sequence_id)
        _validate_non_empty("load_id", load_id)
        _validate_non_empty("object_name", object_name)
        _validate_non_empty("processing_name", processing_name)
        _validate_event("STARTED", "running")

        processing_id = str(uuid.uuid4())

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                processing_id=processing_id,
                load_id=load_id,
                sequence_id=sequence_id,
                object_name=object_name,
                processing_name=processing_name,
                event_type="STARTED",
                event_time=datetime.now(UTC),
                status="running",
                rows_read=0,
                rows_valid=0,
                rows_rejected=0,
                rows_inserted=0,
                rows_updated=0,
                rows_deleted=0,
                error_message=None,
            )
            self._append([row], self._processing_schema(), target)
            logger.info(
                "Traitement '%s' démarré pour l'objet '%s' — processing_id=%s, "
                "load_id=%s, sequence_id=%s.",
                processing_name,
                object_name,
                processing_id,
                load_id,
                sequence_id,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement du démarrage du traitement "
                "'%s' de l'objet '%s' (load_id=%s, sequence_id=%s).",
                processing_name,
                object_name,
                load_id,
                sequence_id,
            )

        return processing_id

    def log_processing_end(
        self,
        sequence_id: str,
        load_id: str,
        processing_id: str,
        object_name: str,
        processing_name: str,
        result: ProcessingResult,
    ) -> None:
        """Enregistre la fin d'une étape technique (event_type=COMPLETED).

        Doit être appelé après la fin de l'étape avec le processing_id
        retourné par log_processing_start.

        Args:
            sequence_id: Identifiant de la séquence parente.
            load_id: Identifiant du chargement parent.
            processing_id: Identifiant retourné par log_processing_start.
            object_name: Nom de l'objet traité.
            processing_name: Nom de l'étape technique (ex : "INGESTION").
            result: Résultat du traitement (statut + métriques).

        """
        target = f"{self._obs_schema}.log_processing"

        if result.status not in _RESULT_TO_EVENT:
            raise ValueError(
                f"ProcessingResult.status invalide : '{result.status}'. "
                f"Valeurs autorisées : {sorted(_RESULT_TO_EVENT)}.",
            )

        event_type_end, status_end = _RESULT_TO_EVENT[result.status]
        _validate_event(event_type_end, status_end)

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                processing_id=processing_id,
                load_id=load_id,
                sequence_id=sequence_id,
                object_name=object_name,
                processing_name=processing_name,
                event_type=event_type_end,
                event_time=datetime.now(UTC),
                status=status_end,
                rows_read=result.rows_read,
                rows_valid=result.rows_valid,
                rows_rejected=result.rows_rejected,
                rows_inserted=result.rows_inserted,
                rows_updated=result.rows_updated,
                rows_deleted=result.rows_deleted,
                error_message=result.error_message,
            )
            self._append([row], self._processing_schema(), target)
            logger.info(
                "Traitement '%s' terminé pour l'objet '%s' — processing_id=%s, "
                "load_id=%s, sequence_id=%s, event_type=%s, statut=%s.",
                processing_name,
                object_name,
                processing_id,
                load_id,
                sequence_id,
                event_type_end,
                status_end,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement de la fin du traitement "
                "'%s' de l'objet '%s' (load_id=%s, sequence_id=%s).",
                processing_name,
                object_name,
                load_id,
                sequence_id,
            )

    # ------------------------------------------------------------------
    # Purge planifiée
    # ------------------------------------------------------------------

    def purge(self, retention_days: int = 365) -> int:
        """Supprime les événements plus anciens que retention_days.

        Seule opération DELETE autorisée — planifiée, non concurrente.
        Filtre sur la colonne event_time. Le nombre de lignes supprimées est
        lu depuis l'historique Delta (``operationMetrics.numDeletedRows``)
        plutôt que via un ``count()`` avant/après, qui déclencherait deux
        scans complets des tables (même pattern que
        ``RejectionHandler.write`` pour ``numOutputRows``).

        Args:
            retention_days: Nombre de jours de rétention (>= 0).

        Returns:
            Nombre total de lignes supprimées.

        Raises:
            ValueError: Si retention_days est négatif.
            RuntimeError: Si la purge échoue sur une ou plusieurs tables.

        """
        if retention_days < 0:
            raise ValueError(
                "retention_days doit être supérieur ou égal à 0.",
            )

        cutoff_date = datetime.now(UTC) - timedelta(days=retention_days)

        total_deleted = 0
        failed_tables: list[str] = []

        for table_name in ("log_sequence", "log_load", "log_processing"):
            full_name = f"{self._obs_schema}.{table_name}"

            if not self._spark.catalog.tableExists(full_name):
                logger.warning(
                    "Table ignorée pendant la purge car elle n'existe pas : %s",
                    full_name,
                )
                continue

            try:
                dt = DeltaTable.forName(self._spark, full_name)
                dt.delete(col("event_time") < lit(cutoff_date))

                history = self._spark.sql(
                    f"DESCRIBE HISTORY {full_name} LIMIT 1",
                ).first()
                metrics = history["operationMetrics"] if history else {}
                deleted_count = int(metrics.get("numDeletedRows", 0))
                total_deleted += deleted_count

                logger.info(
                    "Purge terminée pour %s : %d ligne(s) supprimée(s).",
                    full_name,
                    deleted_count,
                )
            except Exception:
                failed_tables.append(full_name)
                logger.exception(
                    "Erreur lors de la purge de la table %s.",
                    full_name,
                )

        if failed_tables:
            raise RuntimeError(
                "La purge a échoué pour les tables suivantes : " + ", ".join(failed_tables),
            )

        return total_deleted
