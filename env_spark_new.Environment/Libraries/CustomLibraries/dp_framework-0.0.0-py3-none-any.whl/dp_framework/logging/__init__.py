"""Logging — Logger 2 niveaux pour le monitoring."""
