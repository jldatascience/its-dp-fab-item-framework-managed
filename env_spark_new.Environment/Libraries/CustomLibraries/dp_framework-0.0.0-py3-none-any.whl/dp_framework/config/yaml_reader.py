"""Lecteur YAML — Charge le mapping et les contracts depuis le lakehouse metadata.

Rôle dans le framework
----------------------
Ce module est le **point d'entrée unique** pour toute la configuration lue depuis
les fichiers YAML. Il est appelé exclusivement depuis les notebooks Fabric (jamais
depuis le ``Pipeline`` lui-même) afin de bien séparer :

- **Lecture I/O de configuration**  → responsabilité du notebook via ``YamlReader``
- **Traitement Spark des données**   → responsabilité du ``Pipeline``

Structure attendue des fichiers metadata (sur Fabric, section Files du lakehouse) ::

    Files/metadata/
    ├── mappings/
    │   └── tables_mapping.yml         # 1 fichier : liste de toutes les tables
    ├── contracts/                     # ADP et BDP
    │   ├── ma_table_1.yml             # 1 fichier par table
    │   └── ma_table_2.yml
    └── connections/
        └── sources.yml                # 1 fichier : toutes les connexions

Cycle de vie typique (dans un notebook Fabric)
----------------------------------------------
::

    from dp_framework.config.yaml_reader import YamlReader

    reader      = YamlReader(spark, "abfss://.../Files/metadata/adp")
    mapping     = reader.read_mapping("ma_table")     # 1 mapping table
    contract    = reader.read_contract("ma_table")    # 1 contract table (ADP)
    connections = reader.read_connections()           # dict de toutes les connexions
"""

from __future__ import annotations

import logging

import yaml
from pyspark.sql import SparkSession

from dp_framework.config.models import (
    ColumnContract,
    DataContract,
    SourceConnection,
    TableMapping,
)

# Logger Python standard — les traces sortent dans la sortie du notebook Fabric.
# Le niveau par défaut est INFO ; configurable via ``dp_framework.configure_logging``.
_log = logging.getLogger(__name__)


class YamlReader:
    """Lit les fichiers YAML de configuration depuis le lakehouse metadata.

    Cette classe encapsule toute la logique de :
    1. **Localisation** des fichiers YAML sous ``metadata_path``
    2. **Lecture** via ``spark.read.text()`` (compatible chemins ABFSS + local)
    3. **Parsing** en modèles typés (dataclasses immuables du module ``models``)
    4. **Mise en cache** du fichier ``tables_mapping.yml`` (relu 1x par instance)

    Le cache est **local à l'instance** : instancier un nouveau ``YamlReader``
    force la relecture. Cela permet de rafraîchir la config en changeant
    d'instance, sans effet de bord global.

    Sur Fabric, les fichiers sont typiquement placés dans la section Files du
    lakehouse : ``abfss://<workspace>@onelake.dfs.fabric.microsoft.com/<lh>/Files/metadata/``

    Usage
    -----
    ::

        reader = YamlReader(spark, "abfss://.../Files/metadata/adp")

        # ADP : besoin du mapping ET du contract
        mapping     = reader.read_mapping("groupementgup")
        contract    = reader.read_contract("groupementgup")
        connections = reader.read_connections()

        # BDP : mapping + contract de sortie + connexions DSO
        mapping     = reader.read_mapping("employee")
        contract    = reader.read_contract("employee")
        connections = reader.read_connections()
    """

    def __init__(self, spark: SparkSession, metadata_path: str) -> None:
        """Instancie un lecteur pointant vers un dossier metadata.

        Args:
            spark: SparkSession active (généralement injectée automatiquement
                dans un notebook Fabric via la variable ``spark``).
            metadata_path: Chemin racine des fichiers metadata. Peut être :

                - un chemin ABFSS Fabric :
                  ``"abfss://ws@onelake.dfs.fabric.microsoft.com/lh.Lakehouse/Files/metadata/adp"``
                - un chemin lakehouse relatif :
                  ``"Files/metadata/adp"``
                - un chemin local pour tests :
                  ``"/tmp/metadata/adp"``

                L'éventuel ``/`` final est supprimé pour éviter les doubles
                slashes lors des concaténations.

        """
        self._spark = spark
        # Normalisation : on supprime le slash final pour permettre
        # des concaténations propres (``f"{path}/mappings/..."``).
        self._metadata_path = metadata_path.rstrip("/")
        # Cache lazy des mappings — chargé au premier appel à _load_all_mappings().
        # ``None`` = pas encore chargé ; ``{}`` = chargé mais fichier vide.
        self._mappings_cache: dict[str, TableMapping] | None = None

    def read_mapping(self, table_name: str) -> TableMapping:
        """Retourne le ``TableMapping`` d'une table depuis ``tables_mapping.yml``.

        Le fichier ``tables_mapping.yml`` contient la liste de toutes les tables
        du data product. Cette méthode charge le fichier entier (avec cache)
        puis retourne l'entrée correspondant à ``table_name``.

        Args:
            table_name: Nom logique de la table (correspond au champ ``name``
                dans le YAML, pas au ``source_table`` ni au ``target_table``).

        Returns:
            Le ``TableMapping`` correspondant à la table demandée.

        Raises:
            ValueError: Si la table n'existe pas dans le fichier. Le message
                d'erreur liste les tables disponibles pour aider au diagnostic.

        Exemple:
            >>> mapping = reader.read_mapping("groupementgup")
            >>> mapping.source_table
            'Groupementgup'
            >>> mapping.load_mode
            'incremental'

        """
        _log.debug("[YamlReader] Lecture du mapping pour la table '%s'", table_name)
        # _load_all_mappings est idempotent grâce au cache → coût réel : 1 lecture I/O
        mappings = self._load_all_mappings()
        if table_name not in mappings:
            # On log ET on lève l'erreur : le log est pratique dans les notebooks
            # Fabric où la stack trace peut être tronquée.
            _log.error(
                "[YamlReader] Table '%s' introuvable dans tables_mapping.yml. Disponibles : %s",
                table_name,
                list(mappings.keys()),
            )
            raise ValueError(
                f"Table '{table_name}' non trouvée dans tables_mapping.yml. "
                f"Tables disponibles: {list(mappings.keys())}",
            )
        _log.debug("[YamlReader] Mapping trouvé pour la table '%s'", table_name)
        return mappings[table_name]

    def read_contract(self, table_name: str) -> DataContract:
        """Retourne le ``DataContract`` d'une table depuis ``contracts/<table>.yml``.

        Un fichier de contract décrit **une seule table** (contrairement au
        mapping qui en décrit plusieurs). Le nom du fichier doit correspondre
        exactement au nom logique de la table (``<table_name>.yml``).

        À utiliser pour les **ADP** et les **BDP**. Pour un BDP, le contrat
        décrit la sortie métier produite par ``Pipeline.transform()``.

        Args:
            table_name: Nom logique de la table. Le fichier attendu est
                ``<metadata_path>/contracts/<table_name>.yml``.

        Returns:
            Le ``DataContract`` avec la liste des colonnes et leurs contraintes DQ.

        Exemple:
            >>> contract = reader.read_contract("groupementgup")
            >>> contract.functional_keys
            ['GroupementGup_ID']
            >>> len(contract.columns)
            12

        """
        path = f"{self._metadata_path}/contracts/{table_name}.yml"
        _log.info("[YamlReader] Lecture du contract '%s' depuis %s", table_name, path)
        content = self._read_yaml_file(path)
        contract = self._parse_contract(content)
        _log.info(
            "[YamlReader] Contract '%s' chargé — %d colonne(s)",
            table_name,
            len(contract.columns),
        )
        return contract

    def list_active_tables(self) -> list[str]:
        """Retourne les noms des tables marquées ``active: true`` dans le mapping.

        Utile pour l'orchestrateur qui doit itérer sur toutes les tables actives
        d'un data product sans forcément connaître leur liste en dur.

        Returns:
            Liste des noms logiques des tables actives (peut être vide).

        Exemple:
            >>> reader.list_active_tables()
            ['groupementgup', 'produit', 'client']
            >>> # Puis dans un pipeline Fabric :
            >>> for table in reader.list_active_tables():
            ...     mapping  = reader.read_mapping(table)
            ...     contract = reader.read_contract(table)
            ...     pipeline.run(mapping, sequence_id, load_id, processing_id, contract=contract)

        """
        mappings = self._load_all_mappings()
        # ``active=True`` est la valeur par défaut (voir ``_parse_mapping``) →
        # filtre explicite pour permettre de désactiver temporairement une table.
        active = [name for name, m in mappings.items() if m.active]
        _log.info(
            "[YamlReader] %d table(s) active(s) sur %d au total",
            len(active),
            len(mappings),
        )
        return active

    def read_connections(self) -> dict[str, SourceConnection]:
        """Retourne les ``SourceConnection`` depuis ``connections/sources.yml``.

        Le fichier ``sources.yml`` déclare l'ensemble des connexions utilisables
        par les mappings via le champ ``source_connection``. Il est requis pour
        ADP comme pour BDP (chaque table doit avoir sa source résolue).

        Returns:
            Dict ``{nom_connexion: SourceConnection}`` — le nom sert de clé
            de référence dans les mappings.

        Exemple de fichier ``sources.yml`` ::

            sources:
              staging_local:
                type: "lakehouse"
                artifact: "lh_staging"
                default_schema: "staging"
              dso_adp_rh:
                type: "synapsesql"
                artifact: "lh_dso"
                workspace_id: null
                default_schema: "schema_rh"

        Exemple d'appel:
            >>> connections = reader.read_connections()
            >>> connections["staging_local"].type
            'lakehouse'
            >>> connections["dso_adp_rh"].artifact
            'lh_dso'

        """
        path = f"{self._metadata_path}/connections/sources.yml"
        _log.info("[YamlReader] Lecture des connexions depuis %s", path)
        content = self._read_yaml_file(path)
        connections = self._parse_connections(content)
        _log.info(
            "[YamlReader] %d connexion(s) chargée(s) : %s",
            len(connections),
            list(connections.keys()),
        )
        return connections

    # ------------------------------------------------------------------
    # Méthodes privées — lecture et parsing des fichiers YAML
    # ------------------------------------------------------------------

    def _load_all_mappings(self) -> dict[str, TableMapping]:
        """Charge et met en cache ``tables_mapping.yml``.

        Le cache est **volontairement à l'échelle de l'instance** : deux appels
        successifs à ``read_mapping()`` ne relisent le fichier qu'une seule fois.
        Créer une nouvelle instance de ``YamlReader`` force la relecture, ce
        qui est utile en cas de mise à jour du YAML pendant une session.

        Le parsing applique les **défauts du bloc ``data_product``** à chaque
        entrée du bloc ``tables`` — ce qui permet de ne pas répéter
        ``dp_type`` et ``source_system`` sur chaque table.

        Returns:
            Dict ``{name: TableMapping}`` de toutes les tables déclarées
            (actives ou non).

        """
        # Court-circuit du cache : évite une lecture I/O redondante quand
        # ``read_mapping`` est appelé plusieurs fois de suite (cas orchestrateur).
        if self._mappings_cache is not None:
            _log.debug(
                "[YamlReader] Cache mappings utilisé (%d table(s))",
                len(self._mappings_cache),
            )
            return self._mappings_cache

        path = f"{self._metadata_path}/mappings/tables_mapping.yml"
        _log.info("[YamlReader] Chargement de tables_mapping.yml depuis %s", path)
        content = self._read_yaml_file(path)

        # Défauts au niveau ``data_product`` : mutualisent ``dp_type``,
        # ``source_system``, etc. pour toutes les tables — évite la duplication
        # dans le YAML.
        dp_defaults = content.get("data_product", {})
        mappings: dict[str, TableMapping] = {}
        # ``.get("tables", [])`` protège contre un fichier vide ou mal formé.
        for tbl in content.get("tables", []):
            mapping = self._parse_mapping(tbl, dp_defaults)
            mappings[mapping.name] = mapping

        _log.info(
            "[YamlReader] %d table(s) chargée(s) depuis tables_mapping.yml",
            len(mappings),
        )
        # Mémorisation du cache pour les appels ultérieurs.
        self._mappings_cache = mappings
        return mappings

    @staticmethod
    def _parse_mapping(tbl: dict, dp_defaults: dict | None = None) -> TableMapping:
        """Construit un ``TableMapping`` depuis un dict YAML (une entrée de ``tables[]``).

        Les défauts appliqués :

        - ``target_schema``   → ``"storage"`` (schéma standard de la couche core)
        - ``target_table``    → ``tbl["name"]`` (nom logique par défaut)
        - ``source_system``   → hérité du bloc ``data_product``
        - ``dp_type``         → hérité du bloc ``data_product``, ``"ADP"`` sinon
        - ``load_mode``       → ``"full"`` (mode le plus simple par défaut)
        - ``scd_type``        → ``2`` (SCD Type 2 par défaut — historisation complète)
        - ``soft_delete``     → ``False``
        - ``active``          → ``True``

        Args:
            tbl: Dict issu d'une entrée ``tables[]`` du YAML.
            dp_defaults: Bloc ``data_product`` du YAML (défauts globaux du DP).

        Returns:
            Un ``TableMapping`` immuable prêt à être passé au ``Pipeline``.

        Exemple d'entrée YAML minimale ::

            - name: "employee"
              source_schema: "schema_rh"
              source_table: "vw_employee_courante"
              source_connection: "dso_adp_rh"

        Résultat équivalent en Python ::

            TableMapping(
                name="employee",
                source_schema="schema_rh",
                source_table="vw_employee_courante",
                target_schema="storage",       # défaut
                target_table="employee",       # défaut = name
                dp_type="ADP",                 # défaut
                load_mode="full",              # défaut
                scd_type=2,                    # défaut
                source_connection="dso_adp_rh",
                ...
            )

        """
        defaults = dp_defaults or {}
        return TableMapping(
            # Champs OBLIGATOIRES — pas de défaut, une KeyError signalera l'oubli.
            name=tbl["name"],
            source_schema=tbl["source_schema"],
            source_table=tbl["source_table"],
            # Champs avec défauts locaux (au niveau table).
            target_schema=tbl.get("target_schema", "storage"),
            target_table=tbl.get("target_table", tbl["name"]),
            # Champs qui peuvent être hérités du bloc ``data_product`` OU définis
            # par table (la valeur table prime sur le défaut du DP).
            source_system=tbl.get("source_system", defaults.get("source_system", "unknown")),
            dp_type=tbl.get("dp_type", defaults.get("dp_type", "ADP")),
            # Champs de comportement du pipeline.
            load_mode=tbl.get("load_mode", "full"),
            scd_type=tbl.get("scd_type", 2),
            watermark_column=tbl.get("watermark_column"),
            soft_delete=tbl.get("soft_delete", False),
            replay_from_date=tbl.get("replay_from_date"),
            active=tbl.get("active", True),
            # Référence vers ``connections/sources.yml``. Obligatoire dans la
            # nouvelle architecture (ADP et BDP), résolu par ``SourceReader``.
            source_connection=tbl.get("source_connection"),
        )

    @staticmethod
    def _parse_connections(content: dict) -> dict[str, SourceConnection]:
        """Construit un dict de ``SourceConnection`` depuis ``sources.yml``.

        Le nom de la connexion (clé du bloc ``sources``) est réinjecté dans
        l'objet ``SourceConnection.name`` pour permettre son affichage dans les
        logs et les erreurs.

        Args:
            content: Dict issu de ``yaml.safe_load()`` du fichier ``sources.yml``.

        Returns:
            Dict ``{nom_connexion: SourceConnection}``.

        Exemple de YAML ::

            sources:
              staging_local:
                type: lakehouse
                artifact: lh_staging
                default_schema: staging

        Résultat en Python ::

            {
              "staging_local": SourceConnection(
                  name="staging_local",
                  type="lakehouse",
                  artifact="lh_staging",
                  workspace_id=None,
                  default_schema="staging",
              ),
            }

        """
        connections: dict[str, SourceConnection] = {}
        # ``.get("sources", {})`` protège contre un fichier vide.
        for name, raw in content.get("sources", {}).items():
            connections[name] = SourceConnection(
                # Champ ``name`` reconstruit depuis la clé du dict — pratique
                # pour tracer la connexion dans les logs.
                name=name,
                type=raw["type"],
                artifact=raw["artifact"],
                # ``workspace_id=None`` ⇒ même workspace Fabric (cas standard).
                workspace_id=raw.get("workspace_id"),
                default_schema=raw.get("default_schema", "dbo"),
            )
        return connections

    @staticmethod
    def _parse_contract(content: dict) -> DataContract:
        """Construit un ``DataContract`` depuis le contenu d'un fichier contract.

        Le contract est composé de deux blocs :

        - ``contract``  : métadonnées (``table_name``, éventuellement version)
        - ``columns``   : liste des colonnes avec leurs contraintes DQ

        Chaque colonne peut avoir plusieurs contraintes :

        - ``functional_key``     : entre dans la clé fonctionnelle (unicité SCD2)
        - ``completeness_check`` : NOT NULL
        - ``validity_check``     : format REGEX ou DATE
        - ``uniqueness_check``   : redondant avec ``functional_key`` mais gardé pour clarté

        Args:
            content: Dict issu de ``yaml.safe_load()`` du fichier contract.

        Returns:
            Un ``DataContract`` immuable.

        Raises:
            ValueError: Si ``contract.table_name`` est absent (champ obligatoire).

        Exemple de contract YAML ::

            contract:
              table_name: "groupementgup"
              version: "1.0"
            columns:
              - name: "GroupementGup_ID"
                source_name: "GroupementGup_ID"
                type: "Integer"
                functional_key: true
                completeness_check: true
              - name: "Start_Date"
                type: "Date"
                validity_check: true
                format_type: "DATE"
                format_value: "yyyy-MM-dd"

        """
        contract_meta = content.get("contract", {})
        table_name = contract_meta.get("table_name")
        # Garde-fou explicite : sans ``table_name`` le contract est inutilisable
        # (impossible de le rattacher à un mapping).
        if not table_name:
            raise ValueError(
                "Champ requis 'contract.table_name' manquant dans le fichier contract YAML."
            )
        # Construction en compréhension : chaque entrée du bloc ``columns`` du
        # YAML devient un ``ColumnContract``.
        # ``source_name`` prend la valeur de ``name`` par défaut : si les noms
        # source et cible sont identiques, on n'a pas besoin de le répéter.
        columns = [
            ColumnContract(
                name=col["name"],
                source_name=col.get("source_name", col["name"]),
                type=col["type"],
                functional_key=col.get("functional_key", False),
                uniqueness_check=col.get("uniqueness_check", False),
                completeness_check=col.get("completeness_check", False),
                validity_check=col.get("validity_check", False),
                format_type=col.get("format_type"),
                format_value=col.get("format_value"),
            )
            for col in content.get("columns", [])
        ]
        _log.debug("[YamlReader] Contract '%s' parsé — %d colonne(s)", table_name, len(columns))
        return DataContract(table_name=table_name, columns=columns)

    def _read_yaml_file(self, path: str) -> dict:
        """Lit un fichier YAML via Spark et le parse en dict Python.

        Utilise ``spark.read.text()`` pour supporter à la fois :

        - les chemins ABFSS Fabric (``abfss://...``)
        - les chemins lakehouse relatifs (``Files/metadata/...``)
        - les chemins locaux (utile pour les tests unitaires)

        Note : ``spark.read.text()`` retourne un DataFrame de lignes, qu'on
        recombine avec ``\\n`` avant de passer à ``yaml.safe_load()``.
        ``safe_load`` (et non ``load``) est utilisé pour éviter l'exécution
        de code arbitraire depuis le YAML — bonne pratique de sécurité.

        Args:
            path: Chemin complet du fichier YAML.

        Returns:
            Dict Python issu du parsing YAML (peut être vide).

        """
        _log.debug("[YamlReader] Lecture du fichier YAML : %s", path)
        # ``spark.read.text`` supporte transparemment ABFSS + local + File API.
        # ``.collect()`` matérialise le fichier — acceptable car les YAML de
        # configuration sont petits (< 1 MB en pratique).
        lines = self._spark.read.text(path).select("value").collect()
        # Reconstruction du contenu ligne par ligne : préserve l'indentation
        # YAML (les espaces en début de ligne sont significatifs).
        yaml_content = "\n".join(row["value"] for row in lines)
        # ``safe_load`` refuse les tags Python (``!!python/object``) → immunise
        # contre l'exécution de code arbitraire depuis un YAML compromis.
        result = yaml.safe_load(yaml_content)
        _log.debug("[YamlReader] Fichier YAML chargé avec succès : %s", path)
        return result
