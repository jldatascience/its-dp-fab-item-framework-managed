"""Package config — re-exporte les modèles depuis models.py."""

from dp_framework.config.models import (
    ColumnContract,
    DataContract,
    ProcessingResult,
    SourceConnection,
    TableMapping,
)

__all__ = [
    "ColumnContract",
    "DataContract",
    "ProcessingResult",
    "SourceConnection",
    "TableMapping",
]
