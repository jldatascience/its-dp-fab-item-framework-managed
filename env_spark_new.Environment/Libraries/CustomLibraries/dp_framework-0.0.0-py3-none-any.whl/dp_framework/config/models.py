"""Modèles de configuration — Dataclasses pour le mapping et les contracts.

Ce module contient les **structures de données immuables** utilisées comme
langage commun entre :

- le ``YamlReader`` (qui les construit depuis les fichiers YAML)
- le ``Pipeline`` (qui les consomme pour orchestrer le traitement)
- les composants métier (``SourceReader``, ``ContractValidator``, ``SCD2Processor``…)

Choix de design
---------------
- **Dataclasses ``frozen=True``** pour la config → garantit l'absence de
  mutation accidentelle pendant l'exécution du pipeline (thread-safety implicite,
  reproductibilité, hashabilité).
- **``ProcessingResult`` non frozen** car il est construit progressivement
  pendant l'exécution du pipeline (statut initial ``success``, écrasé par
  ``failure`` si exception).
- **Pas d'Enums** pour les valeurs comme ``dp_type`` / ``load_mode`` — on
  reste compatible avec la sérialisation YAML native (string simple).

Vue d'ensemble
--------------
::

    YAML (mapping)        →  TableMapping        (immuable, config table)
    YAML (contract)       →  DataContract        (immuable, schéma + DQ)
                             └─ ColumnContract   (immuable, une colonne)
    YAML (sources)        →  SourceConnection    (immuable, connexion source)
    Pipeline.run() retourne  ProcessingResult    (mutable, métriques d'exécution)
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class SourceConnection:
    """Connexion vers une source de données (lakehouse Fabric, SQL endpoint, etc.).

    Représente une entrée du fichier ``connections/sources.yml``. Résolue par
    le ``SourceReader`` via le champ ``TableMapping.source_connection``.

    Attributes:
        name: Nom logique de la connexion (clé dans ``sources.yml``).
            Utilisé pour l'affichage dans les logs et les erreurs.
        type: Type de source. Deux valeurs supportées actuellement :

            - ``"lakehouse"``  : lecture directe via ``spark.table()`` (Delta)
            - ``"synapsesql"`` : lecture via SQL Analytics Endpoint
              (``spark.read.synapsesql()``)
        artifact: Nom de l'artifact Fabric (nom du lakehouse cible).
            Ex : ``"lh_staging"``, ``"lh_dso"``.
        workspace_id: GUID du workspace Fabric contenant l'artifact.
            ``None`` = même workspace que le notebook appelant (cas standard).
            Renseigner uniquement pour les lectures cross-workspace.
        default_schema: Schéma par défaut si ``TableMapping.source_schema`` est vide.
            Ex : ``"dbo"``, ``"staging"``, ``"schema_rh"``.

    Exemple:
        >>> conn = SourceConnection(
        ...     name="dso_adp_rh",
        ...     type="synapsesql",
        ...     artifact="lh_dso",
        ...     workspace_id=None,
        ...     default_schema="schema_rh",
        ... )

    """

    name: str
    type: str  # lakehouse | synapsesql
    artifact: str  # nom de l'artifact Fabric (lakehouse, etc.)
    workspace_id: str | None = None  # None = même workspace Fabric, sinon GUID
    default_schema: str = "dbo"


@dataclass(frozen=True)
class TableMapping:
    """Configuration de mapping source → cible pour une table.

    Représente une entrée du bloc ``tables[]`` du fichier
    ``mappings/tables_mapping.yml``. Contient toute la config nécessaire au
    ``Pipeline`` pour lire, transformer et écrire une table.

    Attributes:
        name: Nom logique de la table (identifiant interne au framework,
            utilisé comme clé dans les logs et les fichiers contract).
        source_schema: Schéma source. Exemple : ``"staging"`` pour ADP,
            ``"schema_rh"`` pour BDP. Peut être vide si ``SourceConnection.default_schema``
            est défini.
        source_table: Nom exact de la table/vue source (respect de la casse !).
            Ex : ``"Groupementgup"`` (table staging), ``"vw_employee_courante"`` (vue DSO).
        target_schema: Schéma cible dans le lakehouse storage. Par défaut ``"storage"``.
        target_table: Nom de la table Delta cible. Par défaut = ``name``.
        source_system: Système source d'origine. Ex : ``"MDM"``, ``"ADP_RH"``.
            Utilisé pour l'observabilité / lineage.
        dp_type: Type de data product. ``"ADP"`` ou ``"BDP"``. Contrôle le
            comportement du ``Pipeline`` (validation contract, transform, etc.).
        load_mode: Mode de chargement. ``"full"`` (overwrite) ou ``"incremental"``
            (nécessite ``watermark_column``).
        scd_type: ``1`` (upsert simple) ou ``2`` (historisation complète).
            Par défaut ``2``.
        watermark_column: Nom de la colonne watermark pour le mode incrémental.
            Ex : ``"date_insert"``. Ignoré si ``load_mode="full"``.
        soft_delete: Active la détection des suppressions logiques (BDP).
            Compare source vs cible et flague ``_is_deleted=true`` sur les
            clés absentes de la source.
        replay_from_date: Filtre optionnel pour rejouer une plage temporelle
            (BDP). Ex : ``"2025-01-01"`` filtre ``_valid_from >= '2025-01-01'``.
        active: Si ``False``, la table est ignorée par ``list_active_tables()``.
            Permet de désactiver temporairement une table sans supprimer sa config.
        source_connection: Nom de la connexion dans ``connections/sources.yml``.
            Obligatoire (ADP et BDP). Résolu par ``SourceReader``.

    Exemple:
        >>> mapping = TableMapping(
        ...     name="employee",
        ...     source_schema="schema_rh",
        ...     source_table="vw_employee_courante",
        ...     target_schema="storage",
        ...     target_table="employee",
        ...     source_system="ADP_RH",
        ...     dp_type="BDP",
        ...     load_mode="full",
        ...     scd_type=2,
        ...     soft_delete=True,
        ...     source_connection="dso_adp_rh",
        ... )

    """

    name: str
    source_schema: str
    source_table: str
    target_schema: str
    target_table: str
    source_system: str
    dp_type: str  # ADP | BDP
    load_mode: str  # full | incremental
    scd_type: int = 2  # 1 | 2
    watermark_column: str | None = None
    soft_delete: bool = False
    replay_from_date: str | None = None
    active: bool = True
    source_connection: str | None = (
        None  # nom de connexion dans connections/sources.yml (ADP et BDP)
    )


@dataclass(frozen=True)
class ColumnContract:
    """Définition d'une colonne dans le data contract.

    Une ligne du bloc ``columns:`` d'un fichier ``contracts/<table>.yml``.
    Combine schéma (nom + type) et règles DQ (complétude, validité, unicité).

    Attributes:
        name: Nom de la colonne dans la table CIBLE (après renommage).
        source_name: Nom de la colonne dans la table SOURCE. Par défaut = ``name``.
            Utile pour renommer une colonne au passage (``fname`` → ``first_name``).
        type: Type déclaré. Une des valeurs suivantes (case-insensitive) :
            ``"String"``, ``"Integer"``, ``"Long"``, ``"Double"``, ``"Date"``,
            ``"Timestamp"``, ``"Boolean"``, ``"Decimal"``.
            Vérifié par ``ContractValidator`` contre le type Spark réel.
        functional_key: Si ``True``, la colonne entre dans la clé primaire
            fonctionnelle, éventuellement composite. Utilisée pour l'unicité
            DQ, le MERGE SCD2 et le soft delete.
            Au moins une colonne du contract DOIT avoir ``functional_key=True``.
        uniqueness_check: Champ informatif conservé pour compatibilité. Le
            contrôle de la clé primaire repose sur ``functional_key``.
        completeness_check: Si ``True``, la colonne ne doit pas être NULL.
            Les lignes violant cette règle sont rejetées.
        validity_check: Si ``True``, la valeur doit matcher ``format_value``
            selon ``format_type``.
        format_type: ``"REGEX"`` ou ``"DATE"``. Requis si ``validity_check=True``.
        format_value: Expression :

            - regex (Java-flavoured pour Spark) si ``format_type="REGEX"``
              — ex : ``"^\\\\d{10}$"`` pour un numéro à 10 chiffres.
            - format de date Spark si ``format_type="DATE"``
              — ex : ``"yyyy-MM-dd"``.

    Exemple:
        >>> col = ColumnContract(
        ...     name="employee_id",
        ...     source_name="EmployeeID",
        ...     type="Integer",
        ...     functional_key=True,
        ...     completeness_check=True,
        ... )

    """

    name: str
    source_name: str
    type: str  # String | Integer | Long | Double | Date | Timestamp | Boolean
    functional_key: bool = False
    uniqueness_check: bool = False
    completeness_check: bool = False
    validity_check: bool = False
    format_type: str | None = None  # REGEX | DATE
    format_value: str | None = None


@dataclass(frozen=True)
class DataContract:
    """Data contract complet d'une table (métadonnées + colonnes).

    Représente le contenu d'un fichier ``contracts/<table>.yml``. Fournit des
    propriétés dérivées (``functional_keys``, ``completeness_columns``,
    ``validity_columns``) qui évitent de recalculer les filtres partout.

    Attributes:
        table_name: Nom logique de la table (doit matcher ``TableMapping.name``).
        columns: Liste ordonnée des ``ColumnContract``. L'ordre du YAML est
            préservé — utile pour la stabilité du renommage.

    Exemple:
        >>> contract = DataContract(
        ...     table_name="employee",
        ...     columns=[
        ...         ColumnContract(name="id", source_name="EmpId",
        ...                        type="Integer", functional_key=True),
        ...         ColumnContract(name="name", source_name="EmpName",
        ...                        type="String", completeness_check=True),
        ...     ],
        ... )
        >>> contract.functional_keys
        ['id']
        >>> contract.completeness_columns
        ['name']

    """

    table_name: str
    columns: list[ColumnContract] = field(default_factory=list)

    @property
    def functional_keys(self) -> list[str]:
        """Retourne les noms cibles des colonnes marquées ``functional_key=True``.

        Utilisées pour :

        - le MERGE SCD2 (jointure sur ces clés)
        - le contrôle d'unicité DQ
        - le soft delete (comparaison des clés source vs cible)

        Exemple:
            >>> contract.functional_keys
            ['employee_id']
        """
        return [c.name for c in self.columns if c.functional_key]

    @property
    def completeness_columns(self) -> list[str]:
        """Retourne les noms cibles des colonnes marquées ``completeness_check=True``.

        Utilisées par le ``QualityChecker`` pour rejeter les lignes contenant
        des NULL sur ces colonnes.
        """
        return [c.name for c in self.columns if c.completeness_check]

    @property
    def validity_columns(self) -> list[ColumnContract]:
        """Retourne les ``ColumnContract`` complets marqués ``validity_check=True``.

        On retourne l'objet entier (pas juste le nom) car le ``QualityChecker``
        a besoin de ``format_type`` et ``format_value`` pour appliquer la règle.
        """
        return [c for c in self.columns if c.validity_check]


@dataclass
class ProcessingResult:
    """Résultat d'un traitement pipeline pour une table.

    **Non frozen** volontairement : le ``Pipeline`` construit progressivement
    ce résultat au fil des étapes, et l'écrase en cas d'exception.

    Utilisé comme :

    - retour de ``Pipeline.run()``
    - argument de ``Logger.log_processing_end()`` pour l'observabilité

    Attributes:
        table_name: Nom logique de la table traitée.
        status: ``"success"`` ou ``"failure"``. En cas de ``failure``,
            ``error_message`` doit être renseigné.
        rows_read: Nombre de lignes lues depuis la source.
        rows_valid: Nombre de lignes passant les contrôles DQ ADP ou BDP.
        rows_rejected: Nombre de lignes envoyées dans le schema ``rejects``.
        rows_inserted: Nombre de lignes insérées dans la table cible
            (nouvelles clés ou nouvelles versions SCD2).
        rows_updated: Nombre de lignes mises à jour dans la table cible
            (SCD1 : upsert de la clé, SCD2 : versions fermées ``_is_current=false``).
        rows_deleted: Nombre de lignes marquées ``_is_deleted=true`` par le
            soft delete (BDP uniquement).
        error_message: Message d'erreur si ``status="failure"``.

    Exemple succès:
        >>> result = ProcessingResult(
        ...     table_name="employee",
        ...     status="success",
        ...     rows_read=1000,
        ...     rows_valid=998,
        ...     rows_rejected=2,
        ...     rows_inserted=50,
        ...     rows_updated=10,
        ...     rows_deleted=1,
        ... )

    Exemple échec:
        >>> result = ProcessingResult(
        ...     table_name="employee",
        ...     status="failure",
        ...     error_message="ContractViolationError: Colonne requise manquante: 'id'",
        ... )

    """

    table_name: str
    status: str  # success | failure
    rows_read: int = 0
    rows_valid: int = 0
    rows_rejected: int = 0
    rows_inserted: int = 0
    rows_updated: int = 0
    rows_deleted: int = 0
    error_message: str | None = None
