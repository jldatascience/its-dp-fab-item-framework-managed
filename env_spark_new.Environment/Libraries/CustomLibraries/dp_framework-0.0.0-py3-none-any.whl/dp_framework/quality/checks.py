"""Contrôles de qualité technique — unicité, complétude, format, doublons.

Rôle dans le pipeline
---------------------
Après validation du contract (types/colonnes attendus), on applique des
**contrôles de qualité fonctionnels** sur les données elles-mêmes. Une ligne
peut être valide côté schéma mais violer des règles métier — par exemple :

- Un champ obligatoire est nul (``completeness``).
- Un email ne respecte pas la regex configurée (``validity`` REGEX).
- Une date n'est pas au format attendu (``validity`` DATE).
- Deux lignes ont la même clé fonctionnelle (``uniqueness``).
- Deux lignes sont entièrement identiques (``duplicate_row``).

Les lignes rejetées ne bloquent **pas** le pipeline : elles sont extraites
dans un DataFrame séparé qui sera écrit dans ``rejects.rej_<table>`` par
le ``RejectionHandler``. Le pipeline continue avec les lignes valides.

Chaque rejet est tracé dans la colonne technique ``_rejection_reason`` sous
la forme ``reason_type:column_name`` (ex : ``completeness:email``). Une même
ligne peut cumuler plusieurs raisons (concaténées avec ``|``).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from dp_framework.config.models import DataContract

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


@dataclass
class QualityResult:
    """Résultat des contrôles qualité : DataFrame valide + DataFrame rejeté.

    Retourné par ``QualityChecker.check()``. Le pipeline utilise :

    - ``valid`` : pour poursuivre vers les colonnes techniques puis l'écriture.
    - ``rejected`` : pour l'écriture dans ``rejects.rej_<table>``.
    - ``rejection_details`` : pour l'audit / le message de log.

    Attributes:
        valid: Lignes ayant passé tous les contrôles (colonne
            ``_rejection_reason`` retirée).
        rejected: Lignes rejetées, avec ``_rejection_reason`` conservée.
        rejection_details: Résumé textuel pour les logs (ex :
            ``["12 ligne(s) rejetée(s)"]``).

    """

    valid: DataFrame
    rejected: DataFrame
    rejection_details: list[str] = field(default_factory=list)


class QualityChecker:
    """Exécute les contrôles DQ techniques et sépare les lignes valides des rejets.

    Contrôles appliqués dans l'ordre :

    1. **Complétude** : champs obligatoires non nuls (``contract.completeness_columns``).
    2. **Validité de format** : REGEX ou DATE selon ``format_type`` du contract.
    3. **Doublons** : lignes métier entièrement identiques (rejette tout le groupe).
    4. **Unicité** : clé fonctionnelle unique (rejette tout le groupe).

    Les contrôles sont **cumulatifs** : une même ligne peut cumuler plusieurs
    raisons de rejet, concaténées avec ``|`` dans ``_rejection_reason``
    (ex : ``completeness:email|validity_regex:phone``).

    Exemple:
        >>> checker = QualityChecker()
        >>> result = checker.check(df_read, contract)
        >>> result.valid.count()      # → 998
        >>> result.rejected.count()   # → 2
    """

    # Nom de la colonne technique utilisée pour tracer les raisons de rejet.
    # Elle est retirée du DataFrame ``valid`` en fin de traitement, mais
    # conservée dans ``rejected`` pour être écrite dans la table de rejets.
    _REJECTION_COL = "_rejection_reason"

    ALL_CHECKS = frozenset({"completeness", "validity", "duplicate_row", "uniqueness"})

    def check(
        self,
        df: DataFrame,
        contract: DataContract,
        enabled_checks: frozenset[str] | None = None,
    ) -> QualityResult:
        """Exécute tous les contrôles et retourne (valid, rejected).

        Séquence :

        1. Ajout de la colonne technique ``_rejection_reason`` (initialisée à null).
        2. Application successive des 4 contrôles — chacun ajoute une raison
           de rejet aux lignes qui violent la règle.
        3. Split : ``valid`` = lignes où ``_rejection_reason IS NULL``,
           ``rejected`` = lignes où ``_rejection_reason IS NOT NULL``.

        Args:
            df: DataFrame source à valider.
            contract: Contract défini dans ``contracts/<table>.yml`` — porte
                les colonnes obligatoires, les clés fonctionnelles, les
                règles de format.

        Returns:
            ``QualityResult(valid, rejected, rejection_details)``. Le pipeline
            écrit ``rejected`` dans ``rejects.rej_<table>`` via le
            ``RejectionHandler``, et poursuit avec ``valid``.

        Exemple:
            >>> # Contract avec ``completeness_columns = ["email"]``
            >>> result = checker.check(df, contract)
            >>> result.valid.count()      # → toutes les lignes avec email non nul
            >>> result.rejected.select("_rejection_reason").show()
            # +---------------------+
            # | _rejection_reason   |
            # +---------------------+
            # | completeness:email  |
            # +---------------------+

        """
        _log.info(
            "[QualityChecker] Début des contrôles DQ pour le contract '%s'",
            contract.table_name,
        )

        # Initialisation de la colonne technique de rejet à null.
        # Chaque contrôle va y ajouter une raison si la ligne est en violation.
        df = df.withColumn(self._REJECTION_COL, F.lit(None).cast("string"))

        # Le pipeline fournit un profil explicite : ADP = tous les contrôles,
        # BDP = complétude + doublons + unicité dans un premier temps.
        checks = self.ALL_CHECKS if enabled_checks is None else enabled_checks
        unsupported_checks = checks - self.ALL_CHECKS
        if unsupported_checks:
            raise ValueError(f"Contrôles DQ non supportés : {sorted(unsupported_checks)}")

        if "completeness" in checks:
            _log.debug("[QualityChecker] Contrôle : complétude")
            df = self._check_completeness(df, contract)

        if "validity" in checks:
            _log.debug("[QualityChecker] Contrôle : validité de format")
            df = self._check_validity(df, contract)

        if "duplicate_row" in checks:
            _log.debug("[QualityChecker] Contrôle : doublons de lignes")
            df = self._check_duplicates(df, contract)

        if "uniqueness" in checks:
            _log.debug("[QualityChecker] Contrôle : unicité de la clé fonctionnelle")
            df = self._check_uniqueness(df, contract)

        # Split valid / rejected : rejetée dès qu'un contrôle a marqué la colonne.
        df_rejected = df.filter(F.col(self._REJECTION_COL).isNotNull())
        # On retire la colonne technique du DataFrame valid — elle ne doit
        # pas polluer la table cible.
        df_valid = df.filter(F.col(self._REJECTION_COL).isNull()).drop(self._REJECTION_COL)

        details = []
        # ``count()`` force l'exécution ⇒ coûteux mais nécessaire pour le log.
        rej_count = df_rejected.count()
        if rej_count > 0:
            details.append(f"{rej_count} ligne(s) rejetée(s)")
            _log.warning(
                "[QualityChecker] %d ligne(s) rejetée(s) pour '%s'",
                rej_count,
                contract.table_name,
            )
        else:
            _log.info("[QualityChecker] Aucun rejet pour '%s'", contract.table_name)

        return QualityResult(valid=df_valid, rejected=df_rejected, rejection_details=details)

    def _check_completeness(self, df: DataFrame, contract: DataContract) -> DataFrame:
        """Marque les lignes avec des champs obligatoires nuls.

        Une ligne violant la complétude reçoit la raison
        ``completeness:<column_name>`` dans ``_rejection_reason``.

        Exemple:
            ``contract.completeness_columns = ["email", "phone"]``
            - email=null              ⇒ raison = ``completeness:email``
            - email=null AND phone=null
              ⇒ raison = ``completeness:email|completeness:phone``
        """
        # On ne contrôle que les colonnes réellement présentes — protège
        # contre les décalages entre le contract et la source.
        cols_to_check = [c for c in contract.completeness_columns if c in df.columns]
        _log.debug(
            "[QualityChecker] Complétude — %d colonne(s) contrôlée(s) : %s",
            len(cols_to_check),
            cols_to_check,
        )
        for col_name in cols_to_check:
            # Condition = colonne null ⇒ on marque la ligne.
            condition = F.col(col_name).isNull()
            reason = f"completeness:{col_name}"
            df = self._add_rejection_reason(df, condition, reason)
        return df

    def _check_validity(self, df: DataFrame, contract: DataContract) -> DataFrame:
        """Marque les lignes avec des formats invalides (REGEX ou DATE).

        Deux types de contrôles :

        - ``REGEX`` : la valeur doit matcher un motif (email, code postal…).
        - ``DATE``  : la valeur doit être parsable au format déclaré
          (ex : ``yyyy-MM-dd``).

        Les valeurs **nulles** sont ignorées ici — la complétude s'en occupe
        si nécessaire.

        Exemple:
            colonne "email", REGEX ``^[^@]+@[^@]+$``
            - "toto"        ⇒ raison = ``validity_regex:email``
            - "a@b.com"     ⇒ aucune raison
            - null          ⇒ aucune raison (géré par completeness)
        """
        _log.debug(
            "[QualityChecker] Validité — %d colonne(s) avec contrainte de format",
            len(contract.validity_columns),
        )
        for col_contract in contract.validity_columns:
            col_name = col_contract.name
            if col_name not in df.columns:
                continue

            if col_contract.format_type == "REGEX" and col_contract.format_value:
                # Contrôle regex — uniquement sur les valeurs non nulles
                condition = F.col(col_name).isNotNull() & ~F.col(col_name).cast("string").rlike(
                    col_contract.format_value
                )
                reason = f"validity_regex:{col_name}"
                df = self._add_rejection_reason(df, condition, reason)

            elif col_contract.format_type == "DATE" and col_contract.format_value:
                # Contrôle de format de date — la conversion doit réussir
                condition = (
                    F.col(col_name).isNotNull()
                    & F.to_date(F.col(col_name).cast("string"), col_contract.format_value).isNull()
                )
                reason = f"validity_date:{col_name}"
                df = self._add_rejection_reason(df, condition, reason)

        return df

    def _check_duplicates(self, df: DataFrame, contract: DataContract) -> DataFrame:
        """Marque toutes les occurrences des lignes métier identiques.

        Approche :

        Les colonnes techniques provenant du DSO sont ignorées : la comparaison
        porte uniquement sur les colonnes métier déclarées dans le contrat.

        Exemple:
            Input : 3 lignes identiques (id=1, name="A")
            - lignes 1, 2 et 3 rejetées : raison = ``duplicate_row``
        """
        _log.debug("[QualityChecker] Détection des lignes entièrement dupliquées")
        data_cols = [column.name for column in contract.columns if column.name in df.columns]
        if not data_cols:
            _log.debug("[QualityChecker] Aucune colonne métier — doublons ignorés")
            return df

        # Une fenêtre de comptage marque chaque membre du groupe, y compris
        # la première occurrence et les groupes contenant des valeurs nulles.
        duplicate_count = F.count("*").over(Window.partitionBy(*data_cols))
        df = df.withColumn("_duplicate_row_count", duplicate_count)
        condition = F.col("_duplicate_row_count") > 1
        df = self._add_rejection_reason(df, condition, "duplicate_row")
        return df.drop("_duplicate_row_count")

    def _check_uniqueness(
        self,
        df: DataFrame,
        contract: DataContract,
    ) -> DataFrame:
        """Vérifie l'unicité de la clé fonctionnelle — rejette tout groupe dupliqué.

        Différent de ``_check_duplicates`` : ici deux lignes peuvent avoir
        des valeurs différentes mais la même clé fonctionnelle (ex : deux
        salaires différents pour le même ``employee_id``). Toutes les lignes
        partageant une clé dupliquée sont rejetées.

        Exemple:
            ``functional_keys = ["employee_id"]``
            - 2 lignes avec ``employee_id=42``, ``name`` différent
              → lignes 1 et 2 : raison = ``uniqueness_key:employee_id``
        """
        keys = contract.functional_keys
        if not keys:
            _log.debug("[QualityChecker] Aucune clé fonctionnelle — contrôle d'unicité ignoré")
            return df

        # Filtrer les colonnes clé effectivement présentes dans le DataFrame
        existing_keys = [k for k in keys if k in df.columns]
        if not existing_keys:
            return df

        _log.debug(
            "[QualityChecker] Contrôle d'unicité sur les clés : %s", existing_keys
        )
        # Même sémantique que duplicate_row : aucune occurrence d'une clé
        # primaire dupliquée ne doit poursuivre vers la table cible.
        duplicate_count = F.count("*").over(Window.partitionBy(*existing_keys))
        df = df.withColumn("_duplicate_key_count", duplicate_count)
        condition = F.col("_duplicate_key_count") > 1
        df = self._add_rejection_reason(df, condition, f"uniqueness_key:{','.join(existing_keys)}")
        return df.drop("_duplicate_key_count")

    def _add_rejection_reason(
        self,
        df: DataFrame,
        condition: F.Column,
        reason: str,
    ) -> DataFrame:
        """Ajoute une raison de rejet à ``_rejection_reason`` (concaténation).

        Logique :

        - Si condition non remplie : on garde la valeur existante.
        - Sinon, si la ligne a déjà une raison : on concatène avec ``|``.
        - Sinon : on met la nouvelle raison.

        Cela permet d'accumuler plusieurs raisons sur une même ligne.

        Exemple:
            Ligne 1 : raison existante = null, condition = True
              → nouvelle raison = ``completeness:email``
            Ligne 2 : raison existante = ``completeness:email``, condition = True
              → nouvelle raison = ``completeness:email|validity_regex:phone``
        """
        return df.withColumn(
            self._REJECTION_COL,
            F.when(
                condition,
                # Condition remplie ⇒ ajouter / concaténer la raison.
                F.when(
                    F.col(self._REJECTION_COL).isNotNull(),
                    F.concat(F.col(self._REJECTION_COL), F.lit("|"), F.lit(reason)),
                ).otherwise(F.lit(reason)),
                # Condition non remplie ⇒ garder la valeur actuelle (peut être null).
            ).otherwise(F.col(self._REJECTION_COL)),
        )
