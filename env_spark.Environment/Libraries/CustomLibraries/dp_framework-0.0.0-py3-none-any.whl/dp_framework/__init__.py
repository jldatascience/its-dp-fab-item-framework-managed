"""dp-framework — Framework PySpark unifié pour Data Products sur Microsoft Fabric.

Rôle
----
Package principal du framework. Expose deux entrées publiques uniquement :

- ``Pipeline`` : classe unique pour orchestrer les traitements ADP et BDP
  (voir ``dp_framework.pipeline`` pour la documentation détaillée).
- ``configure_logging`` : helper pour activer les traces d'exécution du
  framework depuis un notebook Fabric.

Convention de logging (bonne pratique bibliothèque)
---------------------------------------------------
Le package attache un ``NullHandler`` par défaut sur le logger racine
``dp_framework``. Cela évite le warning Python
"No handlers could be found for logger dp_framework" quand le pipeline
tourne sans configuration explicite.

C'est à l'**appelant** (notebook Fabric) de configurer le niveau et le
format via ``configure_logging()`` — voir docstring de la fonction.

Usage minimal
-------------
    from dp_framework import Pipeline, configure_logging
    from dp_framework.config.yaml_reader import YamlReader

    configure_logging("INFO")               # activation traces
    reader = YamlReader(spark, metadata_root)
    mapping = reader.read_mapping(TABLE_NAME)
    contract = reader.read_contract(TABLE_NAME)
    connections = reader.read_connections()
    pipeline = Pipeline(spark, "lh_storage", dp_type="ADP", connections=connections)
    result = pipeline.run(mapping, batch_id="batch-2026-07-24", contract=contract)
"""

import logging as _logging

from dp_framework.pipeline import Pipeline

__version__ = "0.0.0"
# Liste explicite : contrôle ce qui est exposé via ``from dp_framework import *``.
# On garde une API MINIMALE pour éviter de figer des détails internes.
__all__ = ["Pipeline", "configure_logging"]

# Bonne pratique bibliothèque : NullHandler par défaut pour éviter
# "No handlers could be found for logger dp_framework".
# C'est à l'appelant (notebook) de configurer le niveau et le format.
_logging.getLogger("dp_framework").addHandler(_logging.NullHandler())


def configure_logging(level: str = "INFO", fmt: str | None = None) -> None:
    """Active les traces d'exécution du framework dans la console / notebook.

    À appeler **une seule fois** en début de notebook, avant d'instancier
    ``Pipeline``. Après cet appel, les logs INFO/WARNING/ERROR du framework
    apparaissent en sortie de cellule Fabric avec un formatage lisible.

    L'implémentation est idempotente : si un ``StreamHandler`` est déjà
    attaché au logger, la fonction ne l'ajoute pas une deuxième fois
    (évite les logs dupliqués si la fonction est appelée plusieurs fois).

    Args:
        level: Niveau de log souhaité — ``"DEBUG"``, ``"INFO"``,
            ``"WARNING"``, ``"ERROR"``.

            - ``"INFO"``  → toutes les étapes du pipeline (recommandé pour la prod).
            - ``"DEBUG"`` → détails internes (colonnes, hash, connexions…).
        fmt: Format des messages selon la syntaxe ``logging.Formatter``.
            Laissez ``None`` pour le format par défaut (horodatage + niveau
            + nom du logger + message).

    Exemple:
        >>> from dp_framework import configure_logging
        >>> configure_logging()          # niveau INFO (défaut)
        >>> configure_logging("DEBUG")   # traces détaillées pour debug

    """
    # Format par défaut : horodatage + niveau (padded 8 chars) + logger + message.
    _fmt = fmt or "%(asctime)s  %(levelname)-8s  %(name)s — %(message)s"
    # Conversion string → constante int du module ``logging`` (INFO=20, etc.).
    # ``getattr`` avec fallback ``INFO`` protège contre les typos.
    _level = getattr(_logging, level.upper(), _logging.INFO)

    # On ne modifie QUE le logger du package (pas le root logger) pour ne
    # pas polluer les logs des autres bibliothèques (pyspark, py4j, delta…).
    pkg_logger = _logging.getLogger("dp_framework")
    pkg_logger.setLevel(_level)

    # Ajout d'un StreamHandler seulement si aucun n'est déjà attaché
    # (hors NullHandler, qui est là par défaut). Rend la fonction idempotente :
    # plusieurs appels ne dupliquent pas les logs.
    if not any(
        isinstance(h, _logging.StreamHandler)
        for h in pkg_logger.handlers
        if not isinstance(h, _logging.NullHandler)
    ):
        handler = _logging.StreamHandler()
        handler.setFormatter(_logging.Formatter(_fmt))
        pkg_logger.addHandler(handler)
