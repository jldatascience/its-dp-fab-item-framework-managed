"""Logger — Logging événementiel append-only dans le schéma ``observability``.

Rôle dans le pipeline
---------------------
Point d'entrée pour tracer TOUS les événements du pipeline dans deux tables
Delta immuables :

- **``log_sequence``** (niveau 1) : suivi d'une exécution globale
  (ex : "nightly ADP", "hourly BDP").
- **``log_processing``** (niveau 2) : suivi table par table à l'intérieur
  d'une séquence (nombre de lignes lues, valides, rejetées, insérées…).

Principes de conception
-----------------------
Chaque changement d'état génère un **nouvel événement immuable** (Delta
append). **Aucun UPDATE, MERGE ou verrouillage** n'est utilisé — c'est un
pattern d'**event sourcing** qui garantit :

- Zéro contention concurrentielle (100% append-only).
- Traçabilité complète (on garde tous les états intermédiaires).
- Simplicité de reprise (rejouer les événements suffit).

L'état "actuel" d'une séquence ou d'un processing s'obtient via des vues
SQL (voir ``sql/views/``) qui agrègent les événements par ``batch_id`` ou
``processing_id`` et prennent le plus récent.

Cycle de vie type (séquence)
-----------------------------
    event_type=STARTED   → status=running   (début de séquence)
    event_type=COMPLETED → status=success   (fin sans erreur)
    event_type=COMPLETED → status=failure   (fin avec erreur)

Cycle de vie type (processing)
------------------------------
    event_type=STARTED   → status=running   (début du traitement)
    event_type=COMPLETED → status=success   (fin sans erreur)
    event_type=COMPLETED → status=failure   (fin avec erreur)

Purge
-----
Une seule opération DELETE est autorisée : la **purge planifiée** basée sur
``event_time`` (rétention configurable, appelée depuis
``nb_purge_logs.py``). Elle ne doit pas être appelée en concurrence avec
des inserts.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime, timedelta

from delta.tables import DeltaTable
from pyspark.sql import Row, SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import (
    IntegerType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

from dp_framework.config.models import ProcessingResult

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Valeurs autorisées — validées par ``_validate_event`` avant chaque insert.
# Tout écart lève une ``ValueError`` explicite, évite les bugs silencieux
# (typo dans un status ⇒ requête agrégée fausse).
# ---------------------------------------------------------------------------

# ``STARTED`` = début d'un cycle, ``COMPLETED`` = fin (succès OU échec).
_VALID_EVENT_TYPES: frozenset[str] = frozenset({"STARTED", "COMPLETED"})

# ``running`` = en cours, ``success`` = terminé OK, ``failure`` = terminé KO.
_VALID_STATUSES: frozenset[str] = frozenset({"running", "success", "failure"})

# Correspondance ``ProcessingResult.status`` → ``(event_type, log_status)``.
# Utilisé par ``end_sequence`` et ``log_processing_end`` pour convertir
# le statut fonctionnel du pipeline en couple event_type/status log.
_RESULT_TO_EVENT: dict[str, tuple[str, str]] = {
    "success": ("COMPLETED", "success"),
    "failure": ("COMPLETED", "failure"),
}

# Couples event_type/status cohérents avec le cycle de vie événementiel.
_VALID_EVENT_STATUS_PAIRS: frozenset[tuple[str, str]] = frozenset(
    {
        ("STARTED", "running"),
        ("COMPLETED", "success"),
        ("COMPLETED", "failure"),
    },
)


def _validate_event(event_type: str, status: str) -> None:
    """Vérifie qu'``event_type``, ``status`` et leur combinaison sont autorisés.

    Défense en profondeur : chaque insert log passe par cette fonction pour
    éviter qu'un caller (typo, bug) ne pollue les tables avec une valeur
    inattendue qui casserait les vues SQL et les dashboards.

    Raises:
        ValueError: Si l'une des valeurs, ou leur combinaison, est invalide.

    """
    if event_type not in _VALID_EVENT_TYPES:
        raise ValueError(
            f"event_type invalide : '{event_type}'. "
            f"Valeurs autorisées : {sorted(_VALID_EVENT_TYPES)}.",
        )
    if status not in _VALID_STATUSES:
        raise ValueError(
            f"status invalide : '{status}'. Valeurs autorisées : {sorted(_VALID_STATUSES)}.",
        )
    if (event_type, status) not in _VALID_EVENT_STATUS_PAIRS:
        raise ValueError(
            "Combinaison event_type/status invalide : "
            f"event_type='{event_type}', status='{status}'. "
            f"Combinaisons autorisées : {sorted(_VALID_EVENT_STATUS_PAIRS)}.",
        )


class Logger:
    """Gère le logging événementiel à 2 niveaux dans le schéma ``observability``.

    Les tables ``log_sequence`` et ``log_processing`` sont des journaux
    immuables en mode **append-only**. Chaque transition d'état ajoute une
    nouvelle ligne. Aucun UPDATE, MERGE ou DELETE n'est effectué (hors
    ``purge()`` planifiée).

    Niveau 1 — ``log_sequence`` (flux global par séquence) :
        event_id, batch_id, sequence_name, event_type, event_time,
        status, tables_count, tables_success, tables_failed, error_message

    Niveau 2 — ``log_processing`` (par table ou activité) :
        event_id, processing_id, batch_id, table_name, event_type,
        event_time, status, rows_read, rows_valid, rows_rejected,
        rows_inserted, rows_updated, rows_deleted, error_message

    Exemple de cycle complet:
        >>> logger.start_sequence(batch_id, "nom_sequence")
        >>> # ... traitement de chaque table ...
        >>> processing_id = logger.log_processing_start(batch_id, table_name)
        >>> logger.log_processing_end(batch_id, processing_id, result)
        >>> logger.end_sequence(batch_id, "nom_sequence", "success",
        ...                     tables_count=1, tables_success=1, tables_failed=0)
    """

    def __init__(self, spark: SparkSession, lakehouse: str) -> None:
        """Instancie le Logger sur un lakehouse donné.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse cible (ex : ``"lh_storage"``).
                Le schéma cible est toujours ``{lakehouse}.observability``.

        """
        self._spark = spark
        self._lakehouse = lakehouse
        # Convention : les logs sont TOUJOURS dans le schéma ``observability``
        # du lakehouse (nom hardcodé pour éviter les configs divergentes
        # entre projets).
        self._obs_schema = f"{lakehouse}.observability"

    # ------------------------------------------------------------------
    # Schémas Delta — définis en Python pour garantir la cohérence entre
    # la création (nb_init_metadata) et les inserts (ici).
    # ------------------------------------------------------------------

    def _sequence_schema(self) -> StructType:
        """Retourne le schéma StructType de la table ``log_sequence``.

        Ce schéma est utilisé pour créer un DataFrame typé avant l'append
        Delta, garantissant que chaque insert respecte le contrat.
        """
        return StructType(
            [
                StructField("event_id", StringType(), False),
                StructField("batch_id", StringType(), False),
                StructField("sequence_name", StringType(), False),
                StructField("event_type", StringType(), False),
                StructField("event_time", TimestampType(), False),
                StructField("status", StringType(), False),
                StructField("tables_count", IntegerType(), False),
                StructField("tables_success", IntegerType(), False),
                StructField("tables_failed", IntegerType(), False),
                StructField("error_message", StringType(), True),
            ],
        )

    def _processing_schema(self) -> StructType:
        """Retourne le schéma StructType de la table ``log_processing``.

        Colonnes de métriques (``rows_*``) non-nullables : on veut 0 plutôt
        que null pour simplifier les agrégations (``SUM``, ``AVG``).
        """
        return StructType(
            [
                StructField("event_id", StringType(), False),
                StructField("processing_id", StringType(), False),
                StructField("batch_id", StringType(), False),
                StructField("table_name", StringType(), False),
                StructField("event_type", StringType(), False),
                StructField("event_time", TimestampType(), False),
                StructField("status", StringType(), False),
                StructField("rows_read", IntegerType(), False),
                StructField("rows_valid", IntegerType(), False),
                StructField("rows_rejected", IntegerType(), False),
                StructField("rows_inserted", IntegerType(), False),
                StructField("rows_updated", IntegerType(), False),
                StructField("rows_deleted", IntegerType(), False),
                StructField("error_message", StringType(), True),
            ],
        )

    # ------------------------------------------------------------------
    # Helper d'écriture Delta
    # ------------------------------------------------------------------

    def _append(self, rows: list[Row], schema: StructType, target: str) -> None:
        """Crée un DataFrame depuis les Rows fournies et l'appende dans la table Delta cible.

        - ``mode("append")`` : ajout garanti (jamais d'écrasement).
        - ``mergeSchema=true`` : tolère l'évolution du schéma (nouvelles
          colonnes ajoutées côté framework sans casser les tables existantes).

        Args:
            rows: Lignes à insérer (une par événement, typiquement 1 seule).
            schema: Schéma StructType attendu (garantit le typage).
            target: Nom complet de la table Delta cible.

        """
        df = self._spark.createDataFrame(rows, schema=schema)
        (df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(target))

    # ------------------------------------------------------------------
    # Niveau 1 — Séquence
    # ------------------------------------------------------------------

    def start_sequence(
        self,
        batch_id: str,
        sequence_name: str,
    ) -> None:
        """Enregistre le démarrage d'une séquence (event_type=STARTED).

        Args:
            batch_id: Identifiant unique de la séquence.
            sequence_name: Nom lisible de la séquence.

        """
        target = f"{self._obs_schema}.log_sequence"
        _validate_event("STARTED", "running")

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                batch_id=batch_id,
                sequence_name=sequence_name,
                event_type="STARTED",
                event_time=datetime.now(UTC),
                status="running",
                tables_count=0,
                tables_success=0,
                tables_failed=0,
                error_message=None,
            )
            self._append([row], self._sequence_schema(), target)
            logger.info(
                "Séquence '%s' démarrée — batch_id=%s.",
                sequence_name,
                batch_id,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement du démarrage de la séquence '%s' (batch_id=%s).",
                sequence_name,
                batch_id,
            )

    def end_sequence(
        self,
        batch_id: str,
        sequence_name: str,
        status: str,
        tables_count: int,
        tables_success: int,
        tables_failed: int,
        error_message: str | None = None,
    ) -> None:
        """Enregistre la fin d'une séquence (event_type=COMPLETED).

        Args:
            batch_id: Identifiant unique de la séquence.
            sequence_name: Nom lisible de la séquence.
            status: Statut final — 'success' ou 'failure'.
            tables_count: Nombre total de tables traitées.
            tables_success: Nombre de tables traitées avec succès.
            tables_failed: Nombre de tables en échec.
            error_message: Message d'erreur optionnel.

        """
        target = f"{self._obs_schema}.log_sequence"

        if status not in _RESULT_TO_EVENT:
            raise ValueError(
                f"status invalide pour end_sequence : '{status}'. "
                f"Valeurs autorisées : {sorted(_RESULT_TO_EVENT)}.",
            )

        event_type, mapped_status = _RESULT_TO_EVENT[status]
        _validate_event(event_type, mapped_status)

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                batch_id=batch_id,
                sequence_name=sequence_name,
                event_type=event_type,
                event_time=datetime.now(UTC),
                status=mapped_status,
                tables_count=tables_count,
                tables_success=tables_success,
                tables_failed=tables_failed,
                error_message=error_message,
            )
            self._append([row], self._sequence_schema(), target)
            logger.info(
                "Séquence batch_id=%s terminée — event_type=%s, statut=%s, "
                "tables=%d (succès=%d, échecs=%d).",
                batch_id,
                event_type,
                mapped_status,
                tables_count,
                tables_success,
                tables_failed,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement de la fin de la séquence (batch_id=%s).",
                batch_id,
            )

    # ------------------------------------------------------------------
    # Niveau 2 — Processing (par table)
    # ------------------------------------------------------------------

    def log_processing_start(
        self,
        batch_id: str,
        table_name: str,
    ) -> str:
        """Enregistre le démarrage du traitement d'une table (event_type=STARTED).

        Doit être appelé immédiatement avant le début du traitement pour
        rendre visible l'état 'running' en temps réel dans les logs.

        Args:
            batch_id: Identifiant de la séquence parente.
            table_name: Nom de la table en cours de traitement.

        Returns:
            processing_id: Identifiant unique à passer à log_processing_end.

        """
        target = f"{self._obs_schema}.log_processing"
        processing_id = str(uuid.uuid4())

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                processing_id=processing_id,
                batch_id=batch_id,
                table_name=table_name,
                event_type="STARTED",
                event_time=datetime.now(UTC),
                status="running",
                rows_read=0,
                rows_valid=0,
                rows_rejected=0,
                rows_inserted=0,
                rows_updated=0,
                rows_deleted=0,
                error_message=None,
            )
            self._append([row], self._processing_schema(), target)
            logger.info(
                "Traitement démarré pour la table '%s' — processing_id=%s, batch_id=%s.",
                table_name,
                processing_id,
                batch_id,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement du démarrage du traitement "
                "de la table '%s' (batch_id=%s).",
                table_name,
                batch_id,
            )

        return processing_id

    def log_processing_end(
        self,
        batch_id: str,
        processing_id: str,
        result: ProcessingResult,
    ) -> None:
        """Enregistre la fin du traitement d'une table (event_type=COMPLETED).

        Doit être appelé après la fin du traitement avec le processing_id
        retourné par log_processing_start.

        Args:
            batch_id: Identifiant de la séquence parente.
            processing_id: Identifiant retourné par log_processing_start.
            result: Résultat du traitement (statut + métriques).

        """
        target = f"{self._obs_schema}.log_processing"

        if result.status not in _RESULT_TO_EVENT:
            raise ValueError(
                f"ProcessingResult.status invalide : '{result.status}'. "
                f"Valeurs autorisées : {sorted(_RESULT_TO_EVENT)}.",
            )

        event_type_end, status_end = _RESULT_TO_EVENT[result.status]
        _validate_event(event_type_end, status_end)

        try:
            row = Row(
                event_id=str(uuid.uuid4()),
                processing_id=processing_id,
                batch_id=batch_id,
                table_name=result.table_name,
                event_type=event_type_end,
                event_time=datetime.now(UTC),
                status=status_end,
                rows_read=result.rows_read,
                rows_valid=result.rows_valid,
                rows_rejected=result.rows_rejected,
                rows_inserted=result.rows_inserted,
                rows_updated=result.rows_updated,
                rows_deleted=result.rows_deleted,
                error_message=result.error_message,
            )
            self._append([row], self._processing_schema(), target)
            logger.info(
                "Traitement terminé pour la table '%s' — processing_id=%s, "
                "batch_id=%s, event_type=%s, statut=%s.",
                result.table_name,
                processing_id,
                batch_id,
                event_type_end,
                status_end,
            )
        except Exception:
            logger.exception(
                "Erreur lors de l'enregistrement de la fin du traitement "
                "de la table '%s' (batch_id=%s).",
                result.table_name,
                batch_id,
            )

    # ------------------------------------------------------------------
    # Purge planifiée
    # ------------------------------------------------------------------

    def purge(self, retention_days: int = 365) -> int:
        """Supprime les événements plus anciens que retention_days.

        Seule opération DELETE autorisée — planifiée, non concurrente.
        Filtre sur la colonne event_time.

        Args:
            retention_days: Nombre de jours de rétention (>= 0).

        Returns:
            Nombre total de lignes supprimées.

        Raises:
            ValueError: Si retention_days est négatif.
            RuntimeError: Si la purge échoue sur une ou plusieurs tables.

        """
        if retention_days < 0:
            raise ValueError(
                "retention_days doit être supérieur ou égal à 0.",
            )

        cutoff_date = datetime.now(UTC) - timedelta(days=retention_days)

        total_deleted = 0
        failed_tables: list[str] = []

        for table_name in ("log_sequence", "log_processing"):
            full_name = f"{self._obs_schema}.{table_name}"

            if not self._spark.catalog.tableExists(full_name):
                logger.warning(
                    "Table ignorée pendant la purge car elle n'existe pas : %s",
                    full_name,
                )
                continue

            try:
                before = self._spark.table(full_name).count()

                dt = DeltaTable.forName(self._spark, full_name)
                dt.delete(col("event_time") < lit(cutoff_date))

                after = self._spark.table(full_name).count()
                deleted_count = max(before - after, 0)
                total_deleted += deleted_count

                logger.info(
                    "Purge terminée pour %s : %d ligne(s) supprimée(s).",
                    full_name,
                    deleted_count,
                )
            except Exception:
                failed_tables.append(full_name)
                logger.exception(
                    "Erreur lors de la purge de la table %s.",
                    full_name,
                )

        if failed_tables:
            raise RuntimeError(
                "La purge a échoué pour les tables suivantes : " + ", ".join(failed_tables),
            )

        return total_deleted
