"""Soft Delete — Détection et marquage des suppressions logiques (BDP).

Rôle dans le pipeline
---------------------
Sur les tables BDP en mode ``full``, la source ne notifie pas les
suppressions : une ligne présente hier et absente aujourd'hui **doit** être
considérée comme supprimée côté cible. Le ``SoftDeleteProcessor`` détecte
ces suppressions par **différence de clés** :

1. Lire les clés fonctionnelles actives dans la cible
   (``_is_current=true AND _is_deleted=false``).
2. Comparer avec les clés présentes dans la source.
3. ``target_keys - source_keys`` = clés à marquer comme supprimées.
4. MERGE UPDATE ⇒ ``_is_deleted=true``, ``_deleted_at=now()``.

C'est un **soft delete** : la ligne n'est jamais physiquement supprimée,
elle est simplement flaggée. Cela préserve l'audit et permet la reprise
(un ``_is_deleted=false`` restaurerait la ligne).

Prérequis
---------
- La table cible doit avoir les colonnes SCD2 (``_is_current``) et soft
  delete (``_is_deleted``, ``_deleted_at``) — ce que garantit
  ``SCD2Processor``.
- Le contract doit déclarer des ``functional_keys`` — sinon impossible de
  faire la différence.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from dp_framework.config.models import DataContract, TableMapping

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


@dataclass
class SoftDeleteMetrics:
    """Métriques d'une passe de soft delete.

    Attributes:
        rows_deleted: Nombre de lignes marquées ``_is_deleted=true`` par
            cette exécution. 0 si aucune suppression détectée ou si la
            table cible n'existe pas encore.

    """

    rows_deleted: int = 0


class SoftDeleteProcessor:
    """Compare source et cible pour détecter et marquer les lignes supprimées.

    Logique :

    - Les clés présentes dans la cible (``_is_current=true`` et
      ``_is_deleted=false``) mais **absentes de la source** sont marquées
      comme supprimées.
    - UPDATE ⇒ ``_is_deleted=true``, ``_deleted_at=current_timestamp()``.

    Attention : c'est un **soft delete** — la ligne reste physiquement en
    table pour audit. Elle est simplement filtrable via ``_is_deleted=false``.

    Exemple:
        >>> processor = SoftDeleteProcessor(spark, "lh_storage")
        >>> metrics = processor.apply(df_source, mapping, contract, batch_id, processing_id)
        >>> metrics.rows_deleted
        3   # 3 lignes présentes hier mais absentes aujourd'hui
    """

    def __init__(self, spark: SparkSession, lakehouse: str) -> None:
        """Instancie le processor avec sa SparkSession et le lakehouse cible.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse contenant la table cible.

        """
        self._spark = spark
        self._lakehouse = lakehouse

    def apply(
        self,
        df_source: DataFrame,
        mapping: TableMapping,
        contract: DataContract,
        batch_id: str,
        processing_id: str,
    ) -> SoftDeleteMetrics:
        """Applique le soft delete en comparant les clés source et cible.

        Séquence :

        1. Court-circuit si pas de clé fonctionnelle ou si la table cible
           n'existe pas encore (premier chargement).
        2. Extraction des clés distinctes de la source.
        3. Extraction des clés actives de la cible
           (``_is_current=true AND _is_deleted=false``).
        4. Différence ``target - source`` = clés à supprimer.
        5. MERGE UPDATE avec traçabilité complète (batch/processing IDs).

        Args:
            df_source: DataFrame source (typiquement DSO en mode full).
            mapping: Configuration de la table (détermine le nom cible).
            contract: Data contract — porte les ``functional_keys``.
            batch_id: Identifiant du batch courant (traçabilité).
            processing_id: Identifiant du step de traitement (traçabilité).

        Returns:
            ``SoftDeleteMetrics(rows_deleted=N)``.

        Exemple:
            Cible hier : ids [1, 2, 3, 4] tous ``_is_deleted=false``.
            Source aujourd'hui : ids [1, 2, 4].
            → id=3 est marqué ``_is_deleted=true``, ``_deleted_at=now()``.

        """
        # Import différé de ``DeltaTable`` — la lib peut ne pas être présente
        # hors Fabric/Databricks, et on ne veut pas casser les tests unitaires
        # qui n'utilisent pas le soft delete.
        from delta.tables import DeltaTable

        # Construction de la référence complète de la table cible.
        target_table = f"{self._lakehouse}.{mapping.target_schema}.{mapping.target_table}"
        keys = contract.functional_keys

        # Sans clé fonctionnelle, la différence source/cible est indéfinie.
        # On log un warning explicite pour aider le diagnostic.
        if not keys:
            _log.warning(
                "[SoftDelete][%s] Aucune clé fonctionnelle — soft delete ignoré",
                mapping.name,
            )
            return SoftDeleteMetrics()

        # Vérifier l'existence de la cible avant toute lecture.
        # ``spark.catalog.tableExists()`` est préférable à un try/except sur
        # ``spark.table()`` : plus rapide, sémantique explicite, pas d'exception
        # à capturer (Python 3.10+ / Spark 3.5+).
        if not self._spark.catalog.tableExists(target_table):
            _log.info(
                "[SoftDelete][%s] Table cible '%s' absente — soft delete ignoré",
                mapping.name,
                target_table,
            )
            return SoftDeleteMetrics()

        # Extraction des clés source (distinct pour éviter les doublons).
        source_keys = df_source.select(*keys).distinct()

        # Extraction des clés actives de la cible :
        # - ``_is_current=true``   ⇒ version courante SCD2 uniquement
        # - ``_is_deleted=false``  ⇒ pas déjà supprimée
        target_active = (
            self._spark.table(target_table)
            .filter("_is_current = true AND _is_deleted = false")
            .select(*keys)
        )

        # Différence ensembliste : clés cible - clés source.
        # ``subtract`` = set difference (déduplique automatiquement).
        keys_to_delete = target_active.subtract(source_keys)
        # Coûteux mais nécessaire pour éviter un MERGE inutile si count=0.
        count = keys_to_delete.count()
        _log.info("[SoftDelete][%s] %d clé(s) à marquer supprimée(s)", mapping.name, count)

        if count == 0:
            _log.info("[SoftDelete][%s] Aucune suppression logique détectée", mapping.name)
            return SoftDeleteMetrics()

        # MERGE UPDATE : marquer les lignes correspondantes comme supprimées.
        _log.info(
            "[SoftDelete][%s] Application du MERGE de suppression logique sur '%s'",
            mapping.name,
            target_table,
        )
        dt = DeltaTable.forName(self._spark, target_table)
        # Condition de jointure : match sur les clés fonctionnelles ET filtre
        # sur les lignes actives non déjà supprimées (double sécurité).
        join_condition = (
            " AND ".join(
                [f"target.{k} = del_keys.{k}" for k in keys],
            )
            + " AND target._is_current = true AND target._is_deleted = false"
        )

        (
            dt.alias("target")
            .merge(keys_to_delete.alias("del_keys"), join_condition)
            .whenMatchedUpdate(
                set={
                    # Flag principal : ligne considérée comme supprimée.
                    "_is_deleted": "true",
                    # Timestamp de la suppression (audit).
                    "_deleted_at": "current_timestamp()",
                    # ``_updated_at`` reflète la dernière modification —
                    # ici la suppression logique.
                    "_updated_at": "current_timestamp()",
                    # Traçabilité vers le run qui a fait la suppression.
                    "_batch_id": F.lit(batch_id),
                    "_processing_id": F.lit(processing_id),
                },
            )
            .execute()
        )

        _log.info(
            "[SoftDelete][%s] Soft delete terminé — %d ligne(s) marquée(s)",
            mapping.name,
            count,
        )
        return SoftDeleteMetrics(rows_deleted=count)
