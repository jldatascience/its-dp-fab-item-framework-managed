"""Writer — Écriture Delta (upsert/overwrite) pour SCD Type 1 ou mode full.

Rôle dans le pipeline
---------------------
Point d'écriture pour les tables **non historisées** (SCD1) ou en mode
**full overwrite**. Distinct du ``SCD2Processor`` qui gère l'historisation.

Deux modes selon ``mapping.load_mode`` :

- **``full``** : ``overwrite`` complet de la table. Utilisé quand la source
  est petite ou lorsqu'on ne peut pas fiabiliser un incrémental.
- **``incremental``** (SCD1) : ``MERGE`` upsert sur la clé fonctionnelle.
  Insère les nouvelles lignes et met à jour les existantes (**écrase**
  la version précédente, pas d'historique).

Métriques
---------
Les compteurs (``rows_inserted``, ``rows_updated``) sont récupérés depuis
``DESCRIBE HISTORY`` (Delta operationMetrics), pas via ``df.count()`` :
- pas de scan supplémentaire du DataFrame post-write,
- valeurs fournies directement par le moteur Delta,
- clés ``numTargetRowsInserted`` / ``numTargetRowsUpdated`` pour MERGE,
  ``numOutputRows`` pour un overwrite / write simple.

Soft delete
-----------
Si ``mapping.soft_delete=true``, les colonnes ``_is_deleted`` (false par
défaut) et ``_deleted_at`` (null) sont ajoutées au DataFrame **avant**
l'écriture. Elles seront ensuite mises à jour par le ``SoftDeleteProcessor``
sur les lignes supprimées.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from dp_framework.config.models import DataContract, TableMapping

# Logger Python standard — sortie dans la console / notebook Fabric.
_log = logging.getLogger(__name__)


@dataclass
class WriteMetrics:
    """Métriques retournées par l'écriture.

    Attributes:
        rows_inserted: Lignes nouvellement insérées (via INSERT ou branche
            ``whenNotMatchedInsert`` du MERGE).
        rows_updated: Lignes existantes mises à jour (branche
            ``whenMatchedUpdate`` du MERGE). Toujours 0 en mode ``full``.

    """

    rows_inserted: int = 0
    rows_updated: int = 0


class Writer:
    """Écrit les données dans les tables Delta du schéma storage.

    Modes supportés :

    - **``full``** : overwrite complet de la table.
    - **``incremental``** (SCD1) : MERGE upsert sur clé fonctionnelle.

    Utilisation typique :
        >>> writer = Writer(spark, "lh_storage")
        >>> metrics = writer.write(df, mapping, contract, batch_id, processing_id)
        >>> metrics.rows_inserted, metrics.rows_updated
        (150, 30)
    """

    def __init__(self, spark: SparkSession, lakehouse: str) -> None:
        """Instancie le writer avec sa SparkSession et le lakehouse cible.

        Args:
            spark: SparkSession active.
            lakehouse: Nom du lakehouse contenant le schéma cible.

        """
        self._spark = spark
        self._lakehouse = lakehouse

    def write(
        self,
        df: DataFrame,
        mapping: TableMapping,
        contract: DataContract,
        batch_id: str,
        processing_id: str,
    ) -> WriteMetrics:
        """Écrit le DataFrame selon le mode configuré (``full`` ou ``incremental``).

        Séquence :

        1. Si ``soft_delete`` activé ⇒ ajout des colonnes ``_is_deleted`` /
           ``_deleted_at`` (initialisées à false / null).
        2. Dispatch : ``_overwrite()`` si ``full``, sinon ``_upsert()`` (SCD1).

        Args:
            df: DataFrame prêt à écrire (colonnes techniques déjà ajoutées
                par ``add_technical_columns()``).
            mapping: Configuration de la table.
            contract: Data contract — porte les ``functional_keys`` pour le MERGE.
            batch_id: Identifiant du batch (traçabilité).
            processing_id: Identifiant du step de traitement (traçabilité).

        Returns:
            ``WriteMetrics(rows_inserted, rows_updated)``.

        """
        # Construction du nom complet de la table cible.
        target_table = f"{self._lakehouse}.{mapping.target_schema}.{mapping.target_table}"
        _log.info(
            "[Writer][%s] Écriture vers '%s' — mode=%s",
            mapping.name,
            target_table,
            mapping.load_mode,
        )

        # Ajout des colonnes soft delete si activé — initialisées à false/null
        # au moment de l'INSERT. Le ``SoftDeleteProcessor`` les mettra à jour
        # plus tard pour les lignes disparues de la source.
        if mapping.soft_delete:
            df = df.withColumn("_is_deleted", F.lit(False)).withColumn(
                "_deleted_at", F.lit(None).cast("timestamp")
            )

        # Dispatch selon le mode de chargement.
        if mapping.load_mode == "full":
            return self._overwrite(df, target_table)
        return self._upsert(df, target_table, contract.functional_keys, batch_id, processing_id)

    def _overwrite(self, df: DataFrame, target_table: str) -> WriteMetrics:
        """Mode ``full`` : overwrite complet de la table.

        - ``mode("overwrite")`` : remplace intégralement le contenu.
        - ``overwriteSchema=true`` : autorise l'évolution du schéma
          (nouvelles colonnes ajoutées côté source).
        - Métriques via ``DESCRIBE HISTORY`` ⇒ pas de ``df.count()`` post-write
          (qui déclencherait un second scan complet du DataFrame).

        Args:
            df: DataFrame à écrire.
            target_table: Nom complet ``{lakehouse}.{schema}.{table}``.

        Returns:
            ``WriteMetrics(rows_inserted=N, rows_updated=0)``.

        """
        _log.info("[Writer] Overwrite complet de la table '%s'", target_table)
        df.write.format("delta").mode("overwrite").option(
            "overwriteSchema",
            "true",
        ).saveAsTable(target_table)
        # Récupération des métriques Delta via l'historique — plus efficace
        # qu'un ``df.count()`` post-write.
        history = self._spark.sql(
            f"DESCRIBE HISTORY {target_table} LIMIT 1",
        ).first()
        metrics = history["operationMetrics"] if history else {}
        count = int(metrics.get("numOutputRows", 0))
        _log.info(
            "[Writer] Overwrite terminé — %d ligne(s) écrite(s) dans '%s'",
            count,
            target_table,
        )
        return WriteMetrics(rows_inserted=count)

    def _upsert(
        self,
        df: DataFrame,
        target_table: str,
        keys: list[str],
        batch_id: str,
        processing_id: str,
    ) -> WriteMetrics:
        """Mode ``incremental`` SCD1 : MERGE upsert sur la clé fonctionnelle.

        Comportement :

        - **INSERT** (nouvelle clé) : toutes les colonnes du source, y compris
          ``_created_at`` (initialisé par ``add_technical_columns``).
        - **UPDATE** (clé existante) : toutes les colonnes sauf ``_created_at``
          (préservé pour tracer l'âge original de la ligne). ``_updated_at``,
          ``_batch_id`` et ``_processing_id`` sont rafraîchis.

        Premier chargement (table absente) : écriture directe en overwrite,
        pas de MERGE (Delta a besoin de la table pour construire le plan MERGE).

        Args:
            df: DataFrame à upserter.
            target_table: Nom complet de la table cible.
            keys: Clés fonctionnelles (colonnes de jointure du MERGE).
            batch_id: Identifiant du batch.
            processing_id: Identifiant du step de traitement.

        Returns:
            ``WriteMetrics(rows_inserted, rows_updated)`` — les 2 compteurs
            proviennent des ``operationMetrics`` du MERGE Delta.

        Raises:
            ValueError: Si ``keys`` est vide (impossible de faire un MERGE
                sans clé de jointure).

        Exemple:
            Table cible existe, ligne id=42 déjà présente.
            df = [id=42 (updated), id=99 (new)]
            → MERGE : 1 UPDATE (id=42), 1 INSERT (id=99)
            → WriteMetrics(rows_inserted=1, rows_updated=1)

        """
        # Import différé — voir explication dans soft_delete.py.
        from delta.tables import DeltaTable

        if not keys:
            # Sans clé de jointure, on ne peut pas faire un MERGE : on lève
            # une erreur explicite plutôt que de silently overwrite.
            raise ValueError("Clés fonctionnelles requises pour le mode upsert")

        # Premier chargement : la table n'existe pas encore. On écrit
        # directement en overwrite (Delta a besoin de la table pour bâtir
        # le plan MERGE). ``spark.catalog.tableExists()`` est préféré à un
        # try/except sur ``spark.table()`` (Spark 3.5+, plus rapide).
        if not self._spark.catalog.tableExists(target_table):
            _log.info(
                "[Writer] Table '%s' absente — premier chargement (création directe)",
                target_table,
            )
            # Cache pour count + write sans re-scan du DataFrame source.
            df_cached = df.cache()
            try:
                count = df_cached.count()
                df_cached.write.format("delta").mode("overwrite").saveAsTable(target_table)
            finally:
                # ``unpersist`` garanti — le try/finally évite les fuites
                # mémoire en cas d'exception pendant le write.
                df_cached.unpersist()
            return WriteMetrics(rows_inserted=count)

        _log.info("[Writer] MERGE upsert sur '%s' — clés=%s", target_table, keys)
        dt = DeltaTable.forName(self._spark, target_table)
        # Condition ON du MERGE : match des clés fonctionnelles.
        join_condition = " AND ".join(f"target.{k} = source.{k}" for k in keys)

        # Colonnes à mettre à jour lors d'un UPDATE :
        # - toutes les colonnes SAUF les clés (elles ne changent pas par définition)
        # - SAUF ``_created_at`` (préservé pour tracer l'âge original de la ligne)
        update_cols = {c: f"source.{c}" for c in df.columns if c not in set(keys) | {"_created_at"}}
        # Écrasement explicite des colonnes techniques d'audit à la valeur
        # du run courant (batch/processing IDs, timestamp de mise à jour).
        update_cols["_updated_at"] = "current_timestamp()"
        update_cols["_batch_id"] = F.lit(batch_id)
        update_cols["_processing_id"] = F.lit(processing_id)

        # Colonnes à insérer (toutes les colonnes du DataFrame source).
        insert_cols = {c: f"source.{c}" for c in df.columns}

        # Exécution du MERGE : Delta calcule le plan optimal, ouvre les
        # partitions nécessaires, applique INSERT + UPDATE en une transaction.
        (
            dt.alias("target")
            .merge(df.alias("source"), join_condition)
            .whenMatchedUpdate(set=update_cols)
            .whenNotMatchedInsert(values=insert_cols)
            .execute()
        )

        # Récupération des métriques depuis l'historique Delta (dernière opération).
        # ``numTargetRowsInserted`` et ``numTargetRowsUpdated`` sont populées
        # spécifiquement pour les MERGE (contrairement à ``numOutputRows``
        # utilisé pour les writes simples).
        history = self._spark.sql(
            f"DESCRIBE HISTORY {target_table} LIMIT 1",
        ).first()
        metrics = history["operationMetrics"] if history else {}
        result = WriteMetrics(
            rows_inserted=int(metrics.get("numTargetRowsInserted", 0)),
            rows_updated=int(metrics.get("numTargetRowsUpdated", 0)),
        )
        _log.info(
            "[Writer] MERGE terminé sur '%s' — insérées=%d, mises à jour=%d",
            target_table,
            result.rows_inserted,
            result.rows_updated,
        )
        return result
